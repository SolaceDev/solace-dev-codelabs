# src/agent/protocol/__init__.py
# Intentionally empty
