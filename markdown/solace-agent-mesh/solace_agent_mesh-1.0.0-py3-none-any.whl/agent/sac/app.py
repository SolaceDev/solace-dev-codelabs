# src/agent/sac/app.py

# CRITICAL: Import asyncio fix BEFORE any other imports that might use asyncio
import sys
import os

from solace_ai_connector.common.log import log

# Add the src directory to the path so we can import our fix
sys.path.insert(0, os.path.join(os.path.dirname(os.path.dirname(os.path.dirname(__file__)))))

# Import and apply the asyncio fix immediately
from common.utils.asyncio_macos_fix import ensure_asyncio_compatibility
ensure_asyncio_compatibility()

# TODO - as soon as the ADK is fixed, remove this patching code
# Patch ADK file on disk before any imports
def _patch_adk_file_on_disk():
    """Directly modify the source file on disk before any imports."""
    try:
        import sys
        import os

        relative_module_path = os.path.join(
            "google", "adk", "tools", "_automatic_function_calling_util.py"
        )
        module_file = None

        for path_entry in sys.path:
            potential_path = os.path.join(path_entry, relative_module_path)
            if os.path.isfile(potential_path):
                module_file = potential_path
                break

        if module_file is None:
            log.warning("Could not find ADK module '%s' in sys.path", relative_module_path)
            return

        log.info("Found ADK module at: %s", module_file)

        # Check if file exists and is writable
        # os.path.isfile already confirmed it exists, so just check writability
        if not os.access(module_file, os.W_OK):
            log.error("Cannot write to %s", module_file)
            return

        # Read the current content
        with open(module_file, "r", encoding="utf-8") as f:
            content = f.read()

        # Check if already patched
        if "new_func.__doc__ = func.__doc__" in content:
            log.info("ADK module already patched")
        else:
            # Find the location to insert the fix
            lines = content.split("\n")
            patched = False

            for i, line in enumerate(lines):
                # Look for the line where new_func.__signature__ is set
                if "new_func.__signature__ = new_sig" in line:
                    # Extract indentation from the found line
                    indentation = line[: line.find(line.lstrip())]
                    # Insert our fix right after this line, using the extracted indentation
                    lines.insert(i + 1, f"{indentation}new_func.__doc__ = func.__doc__")
                    patched = True
                    break

            if not patched:
                log.error("Could not find insertion point in ADK module")
            else:
                # Write back to file
                with open(module_file, "w", encoding="utf-8") as f:
                    f.write("\n".join(lines))
                log.info("Successfully patched %s", module_file)

    except Exception as e:
        log.error("Failed to patch ADK file (_automatic_function_calling_util.py): %s", e)

    # --- Patch 2: google/adk/models/lite_llm.py ---
        patched = False

        for i, line in enumerate(lines):
            # Look for the line where new_func.__signature__ is set
            if "new_func.__signature__ = new_sig" in line:
                # Extract indentation from the found line
                indentation = line[: line.find(line.lstrip())]
                # Insert our fix right after this line, using the extracted indentation
                lines.insert(i + 1, f"{indentation}new_func.__doc__ = func.__doc__")
                patched = True
                break

        if not patched:
            log.error("Could not find insertion point in ADK module")
            return

        # Write back to file
        with open(module_file, "w", encoding="utf-8") as f:
            f.write("\n".join(lines))

        log.info("Successfully patched %s", module_file)

    except Exception as e:
        log.error("Failed to patch ADK file (_automatic_function_calling_util.py): %s", e)

    # --- Patch 2: google/adk/models/lite_llm.py ---
    try:
        relative_module_path_lite_llm = os.path.join(
            "google", "adk", "models", "lite_llm.py"
        )
        module_file_lite_llm = None

        for path_entry in sys.path:
            potential_path_lite_llm = os.path.join(path_entry, relative_module_path_lite_llm)
            if os.path.isfile(potential_path_lite_llm):
                module_file_lite_llm = potential_path_lite_llm
                break
        
        if module_file_lite_llm is None:
            log.warning("Could not find ADK module '%s' in sys.path", relative_module_path_lite_llm)
            # Do not return immediately, let the function complete if the first patch was attempted.
            # The function will naturally exit after this try-except block for the second patch.
        else:
            log.info("Found ADK module at: %s", module_file_lite_llm)

            if not os.access(module_file_lite_llm, os.W_OK):
                log.error("Cannot write to %s", module_file_lite_llm)
            else:
                with open(module_file_lite_llm, "r", encoding="utf-8") as f:
                    content_lite_llm = f.read()

                # Check if already patched
                if "MALFORMED_FUNCTION_CALL" in content_lite_llm:
                    log.info("ADK module (lite_llm.py) already patched for MALFORMED_FUNCTION_CALL.")
                else:
                    lines_lite_llm = content_lite_llm.split("\n")
                    patched_lite_llm = False
                    insertion_index_lite_llm = -1
                    base_indentation_lite_llm = ""

                    # Find the insertion point: the line before "if aggregated_llm_response:"
                    # The new "elif" blocks should be inserted just before this "if".
                    for i, line in enumerate(lines_lite_llm):
                        stripped_line = line.lstrip()
                        if stripped_line.startswith('elif finish_reason == "stop" and text:'):
                            # Determine the indentation from a preceding 'elif' or the 'if' itself
                            # Search backwards for a line starting with 'elif' at a similar or lesser indent
                            # to determine the correct base indentation for the new 'elif' blocks.
                            # For simplicity, we'll assume the 'if aggregated_llm_response:' line
                            # is at the correct outer indentation level for the new 'elif' blocks.
                            base_indentation_lite_llm = line[:len(line) - len(stripped_line)]
                            insertion_index_lite_llm = i 
                            break
                    
                    if insertion_index_lite_llm != -1:
                        patch_lines_lite_llm = [
                            f'{base_indentation_lite_llm}elif finish_reason == "MALFORMED_FUNCTION_CALL":',
                            f'{base_indentation_lite_llm}  # Create an error response that will allow the LLM to continue',
                            f'{base_indentation_lite_llm}  aggregated_llm_response = _message_to_generate_content_response(',
                            f'{base_indentation_lite_llm}      ChatCompletionAssistantMessage(',
                            f'{base_indentation_lite_llm}        role="assistant", ',
                            f'{base_indentation_lite_llm}        content="I attempted to call a function that doesn\'t exist or with invalid parameters. Let me try a different approach or provide a direct response instead."',
                            f'{base_indentation_lite_llm}      ),',
                            f'{base_indentation_lite_llm}      is_partial=True,',
                            f'{base_indentation_lite_llm}  )',
                            f'{base_indentation_lite_llm}  text = ""',

                            # The below patch only seems to work for gemini models but causes claude models to go into an infinite loop
                            # f'{base_indentation_lite_llm}elif finish_reason and (not chunk or not text):',
                            # f'{base_indentation_lite_llm}  aggregated_llm_response = _message_to_generate_content_response(',
                            # f'{base_indentation_lite_llm}      ChatCompletionAssistantMessage(role="assistant", content=f"Unexpected finish reason {{finish_reason}} from the LLM. Please verify your request and try again (within reason)."),',
                            # f'{base_indentation_lite_llm}      is_partial=True,',
                            # f'{base_indentation_lite_llm}  )',
                            # f'{base_indentation_lite_llm}  text = ""',
                        ]
                        
                        # Insert the new lines before the anchor line
                        lines_lite_llm = lines_lite_llm[:insertion_index_lite_llm] + patch_lines_lite_llm + lines_lite_llm[insertion_index_lite_llm:]
                        patched_lite_llm = True

                    if not patched_lite_llm:
                        log.error("Could not find insertion point in ADK module (lite_llm.py)")
                    else:
                        with open(module_file_lite_llm, "w", encoding="utf-8") as f:
                            f.write("\n".join(lines_lite_llm))
                        log.info("Successfully patched %s for MALFORMED_FUNCTION_CALL and other finish_reasons.", module_file_lite_llm)

    except Exception as e:
        log.error("Failed to patch ADK file (lite_llm.py): %s", e)


# Apply the patch immediately, before any other imports
_patch_adk_file_on_disk()

from typing import Any, Dict, List
from solace_ai_connector.flow.app import App
from solace_ai_connector.common.log import log
import re  # Added for sanitization

# Use absolute imports from src/
from ...common.a2a_protocol import (
    get_agent_request_topic,
    get_discovery_topic,
    get_agent_response_subscription_topic,
    get_agent_status_subscription_topic,
)
from ...agent.sac.component import SamAgentComponent  # Use new path
from ...agent.utils.artifact_helpers import DEFAULT_SCHEMA_MAX_KEYS  # Use new path

# Module-level info dictionary required by SAC when using app_module
info = {
    "class_name": "SamAgentApp",
    "description": "Custom App class for SAM Agent Host with namespace prefixing and automatic subscription generation.",
}


class SamAgentApp(App):
    """
    Custom App class for SAM Agent Host that automatically generates
    the required Solace subscriptions based on namespace and agent name,
    and programmatically defines the single SamAgentComponent instance.
    It also defines the expected configuration structure via `app_schema`.
    """

    # Define the expected structure and validation rules for app_config
    app_schema = {
        "config_parameters": [
            # --- A2A Config (Flattened) ---
            {
                "name": "namespace",
                "required": True,
                "type": "string",
                "description": "Absolute topic prefix for A2A communication (e.g., 'myorg/dev').",
            },
            {
                "name": "supports_streaming",
                "required": False,
                "type": "boolean",
                "default": False,
                "description": "Whether this host supports A2A streaming (tasks/sendSubscribe).",
            },
            # --- Core ADK Agent Definition ---
            {
                "name": "agent_name",
                "required": True,
                "type": "string",
                "description": "Unique name for this ADK agent instance.",
            },
            {
                "name": "model",
                "required": True,
                "type": "any",
                "description": "ADK model name (string) or BaseLlm config dict.",
            },
            {
                "name": "instruction",
                "required": False,
                "type": "any",
                "default": "",
                "description": "User-provided instructions for the ADK agent (string or invoke block).",
            },
            {
                "name": "global_instruction",
                "required": False,
                "type": "any",
                "default": "",
                "description": "User-provided global instructions for the agent tree (string or invoke block).",
            },
            {
                "name": "tools",
                "required": False,
                "type": "list",
                "default": [],
                "description": "List of tool configurations (python, mcp, built-in). Each tool can have 'required_scopes'.",
                "items": {  # Schema for each item in the tools list
                    "type": "object",
                    "properties": {
                        "tool_type": {
                            "type": "string",
                            "required": True,
                            "enum": ["python", "mcp", "builtin", "builtin-group"],
                            "description": "Type of the tool.",
                        },
                        "tool_name": {
                            "type": "string",
                            "required": False,  # Required for mcp/builtin, optional for python
                            "description": "Name of the tool (e.g., ADK built-in name, specific MCP tool name). Overwrite function_name for python tools.",
                        },
                        "tool_description": {
                            "type": "string",
                            "required": False,  # Optional, Only for python
                            "description": "Description of the tool to overwrite for python tools. Overwrite the python function description",
                        },
                        "component_module": {  # For python tools
                            "type": "string",
                            "required": False,
                            "description": "Python module for 'python' tool type.",
                        },
                        "function_name": {  # For python tools
                            "type": "string",
                            "required": False,
                            "description": "Function name within the module for 'python' tool type.",
                        },
                        "component_base_path": {  # For python tools
                            "type": "string",
                            "required": False,
                            "description": "Base path for 'python' tool module resolution.",
                        },
                        "connection_params": {  # For mcp tools
                            "type": "object",
                            "required": False,
                            "description": "Connection parameters for 'mcp' tool type.",
                        },
                        "environment_variables": {  # For mcp tools (stdio)
                            "type": "object",
                            "required": False,
                            "description": "Environment variables for 'mcp' tool type with stdio connection.",
                        },
                        "required_scopes": {  # Task 4.1: Added required_scopes for explicit tools
                            "type": "list",
                            "required": False,
                            "default": [],
                            "description": "List of scope strings required to use this specific tool.",
                            "items": {"type": "string"},
                        },
                        "tool_config": {  # New property for tool-specific configuration
                            "type": "object",
                            "required": False,
                            "default": {},
                            "description": "A dictionary holding specific configuration for this tool instance (e.g., API keys, model names for an image generation tool).",
                            "additionalProperties": True,  # Allows any structure for the tool's config
                        },
                        # Other tool-specific properties can exist but are not strictly validated here
                        # unless added to this properties block.
                    },
                },
            },
            {
                "name": "enable_builtin_artifact_tools",
                "required": False,
                "type": "object",
                "default": {"enabled": True},  # Default to enabled state
                "description": "Configuration for built-in artifact management tools, including enablement and required scopes.",
                "properties": {
                    "enabled": {
                        "type": "boolean",
                        "required": False,
                        "default": True,
                        "description": "Enable/disable all built-in artifact tools and related instruction injection.",
                    },
                    "create_artifact_required_scopes": {
                        "type": "list",
                        "required": False,
                        "default": [],
                        "items": {"type": "string"},
                        "description": "Scopes required for the 'create_artifact' built-in tool.",
                    },
                    "list_artifacts_required_scopes": {
                        "type": "list",
                        "required": False,
                        "default": [],
                        "items": {"type": "string"},
                        "description": "Scopes required for the 'list_artifacts' built-in tool.",
                    },
                    "load_artifact_required_scopes": {
                        "type": "list",
                        "required": False,
                        "default": [],
                        "items": {"type": "string"},
                        "description": "Scopes required for the 'load_artifact' built-in tool.",
                    },
                    "signal_artifact_for_return_required_scopes": {
                        "type": "list",
                        "required": False,
                        "default": [],
                        "items": {"type": "string"},
                        "description": "Scopes required for the 'signal_artifact_for_return' built-in tool.",
                    },
                    "apply_embed_and_create_artifact_required_scopes": {
                        "type": "list",
                        "required": False,
                        "default": [],
                        "items": {"type": "string"},
                        "description": "Scopes required for the 'apply_embed_and_create_artifact' built-in tool.",
                    },
                    "extract_content_from_artifact_required_scopes": {
                        "type": "list",
                        "required": False,
                        "default": [],
                        "items": {"type": "string"},
                        "description": "Scopes required for the 'extract_content_from_artifact' built-in tool.",
                    },
                },
            },
            {
                "name": "enable_builtin_data_tools",
                "required": False,
                "type": "object",
                "default": {"enabled": False},  # Default to disabled state
                "description": "Configuration for built-in data analysis tools, including enablement and required scopes.",
                "properties": {
                    "enabled": {
                        "type": "boolean",
                        "required": False,
                        "default": False,
                        "description": "Enable/disable all built-in data analysis tools and related instruction injection.",
                    },
                    "transform_data_with_jq_required_scopes": {
                        "type": "list",
                        "required": False,
                        "default": [],
                        "items": {"type": "string"},
                        "description": "Scopes required for the 'transform_data_with_jq' built-in tool.",
                    },
                },
            },
            {
                "name": "data_tools_config",
                "required": False,
                "type": "object",
                "default": {},
                "description": "Runtime configuration parameters for built-in data analysis tools.",
                "properties": {
                    "sqlite_memory_threshold_mb": {
                        "type": "integer",
                        "required": False,
                        "default": 100,
                        "description": "Size threshold (MB) for using in-memory vs. temp file SQLite DB for CSV input.",
                    },
                    "max_result_preview_rows": {
                        "type": "integer",
                        "required": False,
                        "default": 50,
                        "description": "Max rows to return in preview for SQL/JQ results.",
                    },
                    "max_result_preview_bytes": {
                        "type": "integer",
                        "required": False,
                        "default": 4096,
                        "description": "Max bytes to return in preview for SQL/JQ results (if row limit not hit first).",
                    },
                },
            },
            {
                "name": "planner",
                "required": False,
                "type": "object",
                "default": None,
                "description": "Optional configuration for an ADK planner.",
            },
            {
                "name": "code_executor",
                "required": False,
                "type": "object",
                "default": None,
                "description": "Optional configuration for an ADK code executor.",
            },
            # --- ADK Services Configuration ---
            {
                "name": "session_service",
                "required": True,
                "type": "object",
                "description": "Configuration for ADK Session Service (e.g., { type: 'memory' }).",
                "default": {"type": "memory", "default_behavior": "PERSISTENT"},
                "properties": {
                    "type": {
                        "type": "string",
                        "required": True,
                        "description": "Service type (e.g., 'memory', 'vertex_rag').",
                    },
                    "default_behavior": {
                        "type": "string",
                        "required": False,
                        "default": "PERSISTENT",
                        "enum": ["PERSISTENT", "RUN_BASED"],
                        "description": "Default behavior for session service: 'PERSISTENT' (default) or 'RUN_BASED' for how long to keep the session history.",
                    },
                    # Add other service-specific properties here if needed (e.g., GCS credentials)
                },
            },
            {
                "name": "artifact_service",
                "required": False,
                "type": "object",
                "default": {"type": "memory"},
                "description": "Configuration for ADK Artifact Service (defaults to memory).",
                "properties": {
                    "type": {
                        "type": "string",
                        "required": True,
                        "description": "Service type (e.g., 'memory', 'gcs', 'filesystem').",
                    },
                    "base_path": {
                        "type": "string",
                        "required": False,  # Required only if type is filesystem
                        "description": "Base directory path (required for type 'filesystem').",
                    },
                    "bucket_name": {
                        "type": "string",
                        "required": False,  # Required only if type is gcs
                        "description": "GCS bucket name (required for type 'gcs').",
                    },
                    "artifact_scope": {
                        "type": "string",
                        "required": False,
                        "default": "namespace",
                        "enum": ["namespace", "app", "custom"],
                        "description": "Scope for filesystem artifacts: 'namespace' (default, shared by namespace), 'app' (isolated by app name), 'custom' (use artifact_scope_value).",
                    },
                    "artifact_scope_value": {
                        "type": "string",
                        "required": False,
                        "default": None,
                        "description": "Custom identifier for artifact scope (required if artifact_scope is 'custom').",
                    },
                    # Add other service-specific properties here if needed (e.g., GCS credentials)
                },
            },
            {
                "name": "memory_service",
                "required": False,
                "type": "object",
                "default": {"type": "memory"},
                "description": "Configuration for ADK Memory Service (defaults to memory).",
            },
            # --- Tool Output Handling (Generalized) ---
            {
                "name": "tool_output_save_threshold_bytes",
                "required": False,
                "type": "integer",
                "default": 2048,  # 2KB
                "description": "If any tool's processed output (e.g., extracted content from an artifact, MCP response) exceeds this size (bytes), its full content is saved as a new ADK artifact. This threshold should generally be less than or equal to tool_output_llm_return_max_bytes.",
            },
            {
                "name": "tool_output_llm_return_max_bytes",
                "required": False,
                "type": "integer",
                "default": 4096,  # 4KB
                "description": "Maximum size (bytes) of any tool's (potentially summarized or original) output content returned directly to the LLM. If exceeded, the content will be truncated, and the full original output will be saved as an artifact if not already.",
            },
            # --- LLM-Powered Artifact Extraction Tool Config ---
            {
                "name": "extract_content_from_artifact_config",
                "required": False,
                "type": "object",
                "default": {},
                "description": "Configuration for the LLM-powered artifact extraction tool.",
                "properties": {
                    "supported_binary_mime_types": {
                        "type": "list",
                        "required": False,
                        "default": [],
                        "items": {"type": "string"},
                        "description": "List of binary MIME type patterns (e.g., 'image/png', 'image/*', 'video/mp4') that the tool should attempt to process using its internal LLM.",
                    },
                    "model": {
                        "type": "any",  # Union[str, Dict[str, Any]]
                        "required": False,
                        "default": None,
                        "description": "Specifies the LLM for extraction. String (ADK LLMRegistry name) or dict (LiteLlm config). Defaults to agent's LLM.",
                    },
                },
            },
            # --- Artifact Handling ---
            {
                "name": "artifact_handling_mode",
                "required": False,
                "type": "string",
                "default": "ignore",
                "description": "How to represent created artifacts in A2A messages: 'ignore' (default), 'embed' (include base64 data), 'reference' (include fetch URI).",
            },
            # --- Schema Inference Config ---
            {
                "name": "schema_max_keys",
                "required": False,
                "type": "integer",
                "default": DEFAULT_SCHEMA_MAX_KEYS,  # Use imported default
                "description": "Maximum number of dictionary keys to inspect during schema inference.",
            },
            # --- Embed Resolution Config ---
            {
                "name": "enable_embed_resolution",
                "required": False,
                "type": "boolean",
                "default": True,
                "description": "Enable early-stage processing (state, math, etc.) of dynamic embeds and inject related instructions.",
            },
            {
                "name": "stream_batching_threshold_bytes",
                "required": False,
                "type": "integer",
                "default": 0,
                "description": "Minimum size in bytes for accumulated text from LLM stream before sending a status update. If 0 or less, batching is disabled and updates are sent per chunk. Final LLM chunks are always sent regardless of this threshold.",
            },
            {
                "name": "enable_artifact_content_instruction",
                "required": False,
                "type": "boolean",
                "default": True,
                "description": "Inject instructions about the 'artifact_content' embed type (resolved late-stage, typically by a gateway).",
            },
            # --- Agent Card Definition (Simplified) ---
            {
                "name": "agent_card",
                "required": True,
                "type": "object",
                "description": "Static definition of this agent's capabilities for discovery.",
                "properties": {
                    "description": {
                        "type": "string",
                        "required": False,
                        "default": "",
                        "description": "Concise agent description for discovery.",
                    },
                    "defaultInputModes": {
                        "type": "list",
                        "required": False,
                        "default": ["text"],
                        "description": "Supported input content types.",
                    },
                    "defaultOutputModes": {
                        "type": "list",
                        "required": False,
                        "default": ["text"],
                        "description": "Supported output content types.",
                    },
                    "skills": {
                        "type": "list",
                        "required": False,
                        "default": [],
                        "description": "List of advertised agent skills (A2A AgentSkill structure).",
                    },
                    "documentationUrl": {
                        "type": "string",
                        "required": False,
                        "default": None,
                        "description": "Optional URL for agent documentation.",
                    },
                    "provider": {
                        "type": "object",
                        "required": False,
                        "default": None,
                        "description": "Optional provider information (A2A AgentProvider structure).",
                        "properties": {
                            "organization": {"type": "string", "required": True},
                            "url": {"type": "string", "required": False},
                        },
                    },
                },
            },
            # --- Agent Discovery & Communication ---
            {
                "name": "agent_card_publishing",
                "required": True,
                "type": "object",
                "description": "Settings for publishing the agent card.",
                "properties": {
                    "interval_seconds": {
                        "type": "integer",
                        "required": True,
                        "description": "Publish interval (seconds). <= 0 disables periodic publish.",
                    }
                },
            },
            {
                "name": "agent_discovery",
                "required": True,
                "type": "object",
                "description": "Settings for discovering other agents and injecting related instructions.",
                "properties": {
                    "enabled": {
                        "type": "boolean",
                        "required": False,
                        "default": True,
                        "description": "Enable discovery and instruction injection.",
                    }
                },
            },
            {
                "name": "inter_agent_communication",
                "required": True,
                "type": "object",
                "description": "Configuration for interacting with peer agents.",
                "properties": {
                    "allow_list": {
                        "type": "list",
                        "required": False,
                        "default": ["*"],
                        "description": "Agent name patterns to allow delegation to.",
                    },
                    "deny_list": {
                        "type": "list",
                        "required": False,
                        "default": [],
                        "description": "Agent name patterns to deny delegation to.",
                    },
                    "request_timeout_seconds": {
                        "type": "integer",
                        "required": False,
                        "default": 30,
                        "description": "Timeout for peer requests (seconds).",
                    },
                },
            },
            {
                "name": "inject_system_purpose",
                "required": False,
                "type": "boolean",
                "default": False,
                "description": "If true, injects the system_purpose received from the gateway (via task metadata) into the agent's prompt.",
            },
            {
                "name": "inject_response_format",
                "required": False,
                "type": "boolean",
                "default": False,
                "description": "If true, injects the response_format received from the gateway (via task metadata) into the agent's prompt.",
            },
            {
                "name": "inject_user_profile",
                "required": False,
                "type": "boolean",
                "default": False,
                "description": "If true, injects the user_profile received from the gateway (via task metadata) into the agent's prompt.",
            },
            # --- Configurable Agent Initialization ---
            {
                "name": "agent_init_function",
                "required": False,
                "type": "object",
                "description": "Configuration for the agent's custom initialization function.",
                "properties": {
                    "module": {
                        "type": "string",
                        "required": True,
                        "description": "Python module path for the init function (e.g., 'my_plugin.initializers').",
                    },
                    "name": {
                        "type": "string",
                        "required": True,
                        "description": "Name of the init function within the module.",
                    },
                    "base_path": {
                        "type": "string",
                        "required": False,
                        "description": "Optional base path for module resolution if not in PYTHONPATH.",
                    },
                    "config": {
                        "type": "object",
                        "required": False,
                        "default": {},
                        "additionalProperties": True,
                        "description": "Configuration dictionary for the init function, validated by its Pydantic model.",
                    },
                },
            },
            # --- Configurable Agent Cleanup ---
            {
                "name": "agent_cleanup_function",
                "required": False,
                "type": "object",
                "description": "Configuration for the agent's custom cleanup function.",
                "properties": {
                    "module": {
                        "type": "string",
                        "required": True,
                        "description": "Python module path for the cleanup function.",
                    },
                    "name": {
                        "type": "string",
                        "required": True,
                        "description": "Name of the cleanup function within the module.",
                    },
                    "base_path": {
                        "type": "string",
                        "required": False,
                        "description": "Optional base path for module resolution.",
                    },
                },
            },
            {
                "name": "text_artifact_content_max_length",
                "required": False,
                "type": "integer",
                "default": 1000,
                "minimum": 100,
                "maximum": 100000,
                "description": "Maximum character length for text-based artifact content (100-100000 characters). Binary artifacts are unaffected."
            },
            {
                "name": "max_llm_calls_per_task",
                "required": False,
                "type": "integer",
                "default": 20,
                "description": "Maximum number of LLM calls allowed for a single A2A task. A value of 0 or less means unlimited.",
            },
        ]
    }

    def __init__(self, app_info: Dict[str, Any], **kwargs):
        log.debug("Initializing A2A_ADK_App...")

        # Configuration is validated by SAC framework against app_schema before __init__

        app_config = app_info.get("app_config", {})
        namespace = app_config.get("namespace")
        agent_name = app_config.get("agent_name")

        if not namespace or not isinstance(namespace, str):
            raise ValueError(
                "Internal Error: Namespace missing or invalid after validation."
            )
        if not agent_name or not isinstance(agent_name, str):
            raise ValueError(
                "Internal Error: Agent name missing or invalid after validation."
            )

        # Validate artifact_handling_mode (as schema might not support enum)
        artifact_mode = app_config.get("artifact_handling_mode", "ignore").lower()
        if artifact_mode not in ["ignore", "embed", "reference"]:
            log.warning(
                "Invalid 'artifact_handling_mode' value '%s' in app_config. Using 'ignore'. Allowed values: 'ignore', 'embed', 'reference'.",
                artifact_mode,
            )
            app_config["artifact_handling_mode"] = "ignore"  # Correct the config dict

        # Validate schema_max_keys
        schema_max_keys = app_config.get("schema_max_keys", DEFAULT_SCHEMA_MAX_KEYS)
        if not isinstance(schema_max_keys, int) or schema_max_keys < 0:
            log.warning(
                "Invalid 'schema_max_keys' value '%s' in app_config. Using default: %d.",
                schema_max_keys,
                DEFAULT_SCHEMA_MAX_KEYS,
            )
            app_config["schema_max_keys"] = (
                DEFAULT_SCHEMA_MAX_KEYS  # Correct the config dict
            )

        # Validate custom artifact scope
        artifact_service_config = app_config.get("artifact_service", {})
        if artifact_service_config.get("type") == "filesystem":
            artifact_scope = artifact_service_config.get("artifact_scope", "namespace")
            if artifact_scope == "custom" and not artifact_service_config.get(
                "artifact_scope_value"
            ):
                raise ValueError(
                    "Configuration Error: 'artifact_scope_value' is required when 'artifact_scope' is 'custom'."
                )
            if artifact_scope != "custom" and artifact_service_config.get(
                "artifact_scope_value"
            ):
                log.warning(
                    "Configuration Warning: 'artifact_scope_value' is ignored when 'artifact_scope' is not 'custom'."
                )

        log.info(
            "Configuring A2A_ADK_App for Agent: '%s' in Namespace: '%s'",
            agent_name,
            namespace,
        )

        # Generate Required Subscriptions
        required_topics = [
            get_agent_request_topic(namespace, agent_name),
            get_discovery_topic(namespace),
            get_agent_response_subscription_topic(namespace, agent_name),
            get_agent_status_subscription_topic(namespace, agent_name),
        ]
        generated_subs = [{"topic": topic} for topic in required_topics]
        log.info(
            "Automatically generated subscriptions for Agent '%s': %s",
            agent_name,
            generated_subs,
        )

        # Programmatically Define the Single Component
        # The component's config comes entirely from app_config via self.get_config()
        component_definition = {
            "name": f"{agent_name}_host",
            "component_class": SamAgentComponent,
            "component_config": {},  # CRITICAL: Pass empty dict; component uses app_config
            "subscriptions": generated_subs,
        }

        # Overwrite components list in app_info
        # This ensures the parent class only sees our defined component
        app_info["components"] = [component_definition]
        log.debug("Replaced 'components' in app_info with programmatic definition.")

        # Inject Broker Settings
        broker_config = app_info.setdefault("broker", {})

        # Force input/output enabled for the simplified app model
        broker_config["input_enabled"] = True
        broker_config["output_enabled"] = True
        log.debug("Injected broker.input_enabled=True and broker.output_enabled=True")

        # Generate and inject the queue name WITH namespace prefix
        # Format: {namespace}/q/a2a/{agent_name} - ensures uniqueness across namespaces
        generated_queue_name = f"{namespace.strip('/')}/q/a2a/{agent_name}"
        broker_config["queue_name"] = generated_queue_name
        log.debug("Injected generated broker.queue_name: %s", generated_queue_name)

        # Set the queue to be temporary
        broker_config["temporary_queue"] = True
        log.debug("Set broker_config.temporary_queue = True")

        # Call Parent Init with Modified Config
        # The parent class will now use the modified app_info with the single,
        # programmatically defined component and injected broker settings.
        super().__init__(app_info, **kwargs)
        log.debug("A2A_ADK_App initialization complete.")
