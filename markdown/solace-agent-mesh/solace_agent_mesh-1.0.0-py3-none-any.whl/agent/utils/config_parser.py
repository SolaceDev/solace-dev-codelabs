# src/agent/utils/config_parser.py
"""
Parses and validates configuration for the SamAgentComponent and its App.
"""

from typing import Any, Dict, List, Optional, Union, Callable
import os

from solace_ai_connector.common.log import log
from google.adk.agents.readonly_context import ReadonlyContext

# Type alias for ADK InstructionProvider
InstructionProvider = Callable[[ReadonlyContext], str]


def resolve_instruction_provider(
    component, config_value: Any
) -> Union[str, InstructionProvider]:
    """
    Resolves instruction config which can be a string or an invoke block
    handled by SAC's get_config.

    Args:
        component: The component instance (for context in get_config).
        config_value: The configuration value for the instruction (e.g., the value
                      retrieved using component.get_config("instruction")).

    Returns:
        The resolved instruction string or provider function.

    Raises:
        ValueError: If the configuration is invalid or resolution fails.
    """
    if isinstance(config_value, str):
        return config_value
    elif isinstance(config_value, dict) and "invoke" in config_value:
        # SAC's get_config handles the invoke block resolution
        # Assuming the framework change ensures app_config is resolved before this point
        # We pass the config_value itself to get_config, as it expects the key or the dict
        # Note: This assumes get_config was already called to *get* config_value.
        # If config_value is the *raw* dict from the YAML, this might need adjustment
        # depending on how SAC's get_config handles nested invokes.
        # Let's assume get_config already resolved it if it was an invoke block.
        # If config_value *is* the resolved function, handle it.
        # If it's a string, return it.
        # If it's still a dict with 'invoke', something is wrong or needs re-resolution.

        # Re-evaluating based on the assumption that the caller passes the *value*
        # obtained from get_config("instruction") or get_config("global_instruction").
        # If that value is *already* resolved to a function or string, handle it.
        if callable(config_value):
            # ADK expects Callable[[ReadonlyContext], str].
            # Assume the invoke block returns a function that matches this,
            # or a simpler function that we might need to wrap.
            # For now, trust the user configured the invoke correctly.
            log.info(
                "%s Resolved instruction to a callable provider.",
                component.log_identifier,
            )
            return config_value
        elif isinstance(config_value, str):
            # If get_config resolved the invoke block to a string
            return config_value
        else:
            # If get_config returned something unexpected after resolving an invoke block
            raise ValueError(
                f"Invoke block for instruction resolved to unexpected type: {type(config_value)}"
            )

    elif not config_value:
        return ""  # Default empty string
    else:
        # If the initial config_value was neither a string nor a dict with 'invoke'
        raise ValueError(
            f"Invalid instruction configuration type: {type(config_value)}"
        )
