# src/agent/utils/context_helpers.py
"""
Helper functions for working with invocation contexts in the A2A agent tools.
"""
from typing import Any


def get_original_session_id(invocation_context: Any) -> str:
    """
    Extract the original session ID from an invocation context.
    
    When session IDs contain a colon, this function returns only the part before
    the first colon, which is the original session ID.
    
    Args:
        invocation_context: The invocation context object from tool_context.
                            Typically accessed via `tool_context._invocation_context`.
        
    Returns:
        str: The original session ID (part before the first colon if present).
             Returns the raw ID if no colon is found.
    """
    if not hasattr(invocation_context, 'session') or not hasattr(invocation_context.session, 'id'):
        # Handle cases where the structure might be different or missing
        # You might want to log a warning or raise an error depending on expected guarantees
        # For now, returning an empty string or a specific marker might be safer
        # Or, if invocation_context itself could be the session_id string (less likely given usage)
        if isinstance(invocation_context, str): # Fallback if inv_context IS the session_id
             raw_session_id = invocation_context
        else:
            # This case should ideally not happen if inv_context is always structured
            # Consider logging: log.warning("Invocation context does not have session.id")
            return "" # Or raise an error
    else:
        raw_session_id = invocation_context.session.id

    return raw_session_id.split(':', 1)[0] if ':' in raw_session_id else raw_session_id