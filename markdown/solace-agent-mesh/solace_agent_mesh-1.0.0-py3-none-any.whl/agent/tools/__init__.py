# src/agent/tools/__init__.py
# Intentionally empty
"""
This __init__.py file ensures that all built-in tool modules are imported
when the 'tools' package is loaded. This is crucial for the declarative
tool registration pattern, as it triggers the `tool_registry.register()`
calls within each tool module.
"""

# Import each built-in tool module to ensure they are registered.
from . import builtin_artifact_tools
from . import general_agent_tools
from . import audio_tools
from . import image_tools
from . import web_tools
from . import test_tools

# The peer_agent_tool is not a standard built-in and is handled differently,
# so it is not imported here for registration.
