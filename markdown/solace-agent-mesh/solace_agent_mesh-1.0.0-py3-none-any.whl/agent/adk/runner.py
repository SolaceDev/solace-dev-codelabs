# src/agent/adk/runner.py
"""
Manages the asynchronous execution of the ADK Runner.
"""

import asyncio
from google.adk.agents.invocation_context import LlmCallsLimitExceededError

# Custom exception for signalling task cancellation
class TaskCancelledError(Exception):
    """Raised when an ADK task is cancelled via external signal."""
    pass
import traceback
from typing import Dict, Any

from solace_ai_connector.common.log import log

# ADK Imports
from google.adk.sessions import Session as ADKSession
from google.adk.agents import RunConfig
from google.genai import types as adk_types
from google.adk.events import Event as ADKEvent # Added for context-setting event
from google.adk.events.event_actions import EventActions # Added for state_delta

# A2A Types for cancellation
from ...common.types import CancelTaskRequest, TaskIdParams


async def run_adk_async_task_thread_wrapper(
    component,  # Pass the component instance for context
    adk_session: ADKSession,
    adk_content: adk_types.Content,
    run_config: RunConfig,
    a2a_context: Dict[str, Any],
):
    """
    Wrapper to run the async ADK task.
    This function is now async and expected to be awaited.
    Calls component finalization methods upon completion or error.

    Args:
        component: The SamAgentComponent instance.
        adk_session: The ADK session to use (from component.session_service).
        adk_content: The input content for the ADK agent.
        run_config: The ADK run configuration.
        a2a_context: The context dictionary for this specific A2A request.
    """
    logical_task_id = a2a_context.get(
        "logical_task_id", "unknown_task"
    )
    is_paused = False  # Default to not paused
    try:
        # --- Clear Streaming Text Buffer ---
        component.clear_streaming_text_buffer()
        log.debug(
            "%s Cleared streaming text buffer before starting ADK task %s.",
            component.log_identifier,
            logical_task_id,
        )
        # --- End Clear Streaming Text Buffer ---

        # --- Inject a2a_context into ADK session state via state_delta event ---

        if adk_session and component.session_service:
            context_setting_invocation_id = logical_task_id
            context_setting_event = ADKEvent(
                invocation_id=context_setting_invocation_id,
                author="A2A_Host_System", # System-level author
                content=adk_types.Content(parts=[adk_types.Part(text="Initializing A2A context for task run.")]),
                actions=EventActions(state_delta={"a2a_context": a2a_context}),
                branch=None
            )
            try:
                await component.session_service.append_event(session=adk_session, event=context_setting_event)
                log.info(
                    "%s Appended context-setting event to ADK session %s (via component.session_service) for task %s.",
                    component.log_identifier,
                    adk_session.id,
                    logical_task_id,
                )
            except Exception as e_append:
                log.error(
                    "%s Failed to append context-setting event for task %s: %s. Tool scope filtering might not work if state is not persisted.",
                    component.log_identifier,
                    logical_task_id,
                    e_append
                )
        else:
            log.warning(
                "%s Could not inject a2a_context into ADK session state via event for task %s (session or session_service invalid). Tool scope filtering might not work.",
                component.log_identifier,
                logical_task_id,
            )
        # --- End Inject a2a_context via state_delta event ---

        # This function is now async and runs in the component's event loop context.
        # No need to get target_loop or use asyncio.run_coroutine_threadsafe.

        cancellation_event = asyncio.Event()
        with component.active_task_cancellation_events_lock:
            component.active_task_cancellation_events[logical_task_id] = cancellation_event
        log.debug(
            "%s Stored cancellation event for task %s.",
            component.log_identifier,
            logical_task_id,
        )

        # Directly await the async task and capture if it's paused
        is_paused = await run_adk_async_task(
            component, adk_session, adk_content, run_config, a2a_context, cancellation_event
        )

        log.debug(
            "%s ADK task %s awaited and completed (Paused: %s).",
            component.log_identifier,
            logical_task_id,
            is_paused
        )

    except TaskCancelledError as tce:
        log.info(
            "%s Task %s was cancelled. Finalizing. Message: %s",
            component.log_identifier,
            logical_task_id,
            tce,
        )
        # --- Propagate Cancellation to Peer Sub-Tasks ---
        # Check for active peer sub-tasks associated with this main task.
        with component.active_peer_sub_tasks_lock:
            sub_tasks_to_cancel = component.active_peer_sub_tasks.get(
                logical_task_id, []
            )

        if sub_tasks_to_cancel:
            log.info(
                "%s Propagating cancellation to %d peer sub-task(s) for main task %s.",
                component.log_identifier,
                len(sub_tasks_to_cancel),
                logical_task_id,
            )
            for sub_task_info in sub_tasks_to_cancel:
                sub_task_id = sub_task_info.get("sub_task_id")
                target_peer_agent_name = sub_task_info.get("peer_agent_name")

                if not sub_task_id or not target_peer_agent_name:
                    log.warning(
                        "%s Incomplete sub-task info found, cannot cancel: %s",
                        component.log_identifier,
                        sub_task_info,
                    )
                    continue

                log.info(
                    "%s Propagating cancellation to peer sub-task %s for agent %s.",
                    component.log_identifier,
                    sub_task_id,
                    target_peer_agent_name,
                )
                try:
                    peer_cancel_params = TaskIdParams(id=sub_task_id)
                    peer_cancel_request = CancelTaskRequest(params=peer_cancel_params)
                    peer_cancel_user_props = {"clientId": component.agent_name}
                    peer_request_topic = component._get_agent_request_topic(
                        target_peer_agent_name
                    )

                    component._publish_a2a_message(
                        payload=peer_cancel_request.model_dump(exclude_none=True),
                        topic=peer_request_topic,
                        user_properties=peer_cancel_user_props,
                    )
                    log.info(
                        "%s Sent CancelTaskRequest to peer %s for sub-task %s.",
                        component.log_identifier,
                        target_peer_agent_name,
                        sub_task_id,
                    )
                except Exception as e_peer_cancel:
                    log.error(
                        "%s Failed to send CancelTaskRequest for sub-task %s: %s",
                        component.log_identifier,
                        sub_task_id,
                        e_peer_cancel,
                    )
        # --- End Propagate Cancellation ---
        try:
            component.finalize_task_canceled(a2a_context)
        except Exception as finalize_cancel_err:
            log.exception(
                "%s Critical error during finalize_task_canceled for task %s: %s",
                component.log_identifier,
                logical_task_id,
                finalize_cancel_err,
            )
    except LlmCallsLimitExceededError as llm_limit_e: # New specific catch block
        log.warning(
            "%s LLM call limit exceeded for task %s: %s. Finalizing with user guidance.",
            component.log_identifier,
            logical_task_id,
            llm_limit_e,
        )
        try:
            component.finalize_task_limit_reached(a2a_context, llm_limit_e)
        except Exception as finalize_limit_err:
            log.exception(
                "%s Critical error during finalize_task_limit_reached for task %s: %s",
                component.log_identifier,
                logical_task_id,
                finalize_limit_err,
            )
            # Fallback to generic error if custom finalization fails
            component.finalize_task_error(finalize_limit_err, a2a_context)
    except Exception as e:
        log.exception(
            "%s Exception in ADK runner for task %s: %s",
            component.log_identifier,
            logical_task_id,
            e,
        )
        # --- Call error finalization method on component ---
        try:
            await component.finalize_task_error(e, a2a_context)
        except Exception as finalize_err:
            log.exception(
                "%s Critical error during finalize_task_error for task %s: %s",
                component.log_identifier,
                logical_task_id,
                finalize_err,
            )
    finally:
        # No loop to close here anymore as we are using the component's shared loop.
        # The component's loop is managed by its _start_async_loop and cleanup methods.
        component.clear_task_event_loop(logical_task_id) # Keep if used for tracking

        # This cleanup is for the current invocation, which is now over.
        # It's safe to always clean this up.
        with component.active_task_cancellation_events_lock:
            removed_event = component.active_task_cancellation_events.pop(logical_task_id, None)
            if removed_event:
                log.debug(
                    "%s Removed cancellation event for task %s from active tracking.",
                    component.log_identifier,
                    logical_task_id,
                )

        # This cleanup should ONLY run if the task is NOT paused for a peer.
        if not is_paused:
            # Cleanup Logic for Run-Based Sessions (delete from shared service)
            if a2a_context.get("is_run_based_session"):
                temp_session_id_to_delete = a2a_context.get("temporary_run_session_id_for_cleanup")
                agent_name_for_session = a2a_context.get("agent_name_for_session")
                user_id_for_session = a2a_context.get("user_id_for_session")

                if temp_session_id_to_delete and agent_name_for_session and user_id_for_session:
                    log.info(
                        "%s Cleaning up RUN_BASED session (app: %s, user: %s, id: %s) from shared service for task_id='%s'",
                        component.log_identifier,
                        agent_name_for_session,
                        user_id_for_session,
                        temp_session_id_to_delete,
                        logical_task_id,
                    )
                    try:
                        if component.session_service:
                            log.debug(
                                "%s Attempting to delete session from service %s. App: '%s', User: '%s', SessionID: '%s'",
                                component.log_identifier,
                                type(component.session_service).__name__,
                                agent_name_for_session,
                                user_id_for_session,
                                temp_session_id_to_delete
                            )
                            # Verify the internal state of InMemorySessionService if possible (for debugging)
                            if hasattr(component.session_service, '_sessions'):
                                session_key_to_delete = (agent_name_for_session, user_id_for_session, temp_session_id_to_delete)
                                log.debug(
                                    "%s Keys in InMemorySessionService before delete attempt for %s: %s. Target key present: %s",
                                    component.log_identifier,
                                    temp_session_id_to_delete,
                                    list(component.session_service._sessions.keys()),
                                    session_key_to_delete in component.session_service._sessions
                                )
                            try:
                                await component.session_service.delete_session(
                                    app_name=agent_name_for_session,
                                    user_id=user_id_for_session,
                                    session_id=temp_session_id_to_delete
                                )
                            except Exception:
                                log.warning(
                                    "%s Failed to delete RUN_BASED session (app: %s, user: %s, id: %s) from shared service or session not found.",
                                    component.log_identifier,
                                    agent_name_for_session,
                                    user_id_for_session,
                                    temp_session_id_to_delete
                                )
                        else:
                            log.error("%s component.session_service is None, cannot delete RUN_BASED session %s.", component.log_identifier, temp_session_id_to_delete)
                    except AttributeError:
                        log.error(
                            "%s component.session_service does not support 'delete_session'. Cleanup for RUN_BASED session (app: %s, user: %s, id: %s) skipped.",
                            component.log_identifier,
                            agent_name_for_session,
                            user_id_for_session,
                            temp_session_id_to_delete
                        )
                    except Exception as e_cleanup:
                        log.error(
                            "%s Error cleaning up RUN_BASED session (app: %s, user: %s, id: %s) from shared service: %s",
                            component.log_identifier,
                            agent_name_for_session,
                            user_id_for_session,
                            temp_session_id_to_delete,
                            e_cleanup,
                        )
                else:
                    log.warning(
                        "%s Could not clean up RUN_BASED session for task %s due to missing context (id_to_delete: %s, agent_name: %s, user_id: %s).",
                        component.log_identifier,
                        logical_task_id,
                        temp_session_id_to_delete,
                        agent_name_for_session,
                        user_id_for_session
                    )

            # Cleanup peer sub-task tracking
            with component.active_peer_sub_tasks_lock:
                removed_peer_task = component.active_peer_sub_tasks.pop(logical_task_id, None)
                if removed_peer_task:
                    log.debug(
                        "%s Removed peer sub-task tracking for main task %s.",
                        component.log_identifier,
                        logical_task_id,
                    )
        else:
            log.info(
                "%s Task %s is paused for a long-running tool. Skipping session and peer task cleanup.",
                component.log_identifier,
                logical_task_id,
            )

        log.debug(
            "%s ADK runner for task %s finished.",
            component.log_identifier,
            logical_task_id,
        )


async def run_adk_async_task(
    component,  # Pass the component instance for context
    adk_session: ADKSession,
    adk_content: adk_types.Content,
    run_config: RunConfig,
    a2a_context: Dict[str, Any],  # Added context argument
    cancellation_event: asyncio.Event,  # Added cancellation_event
) -> bool:
    """
    Runs the ADK Runner asynchronously and calls component methods to process
    intermediate events and finalize the task.

    Returns:
        bool: True if the task is paused for a long-running tool, False otherwise.
    """
    logical_task_id = a2a_context.get(
        "logical_task_id", "unknown_task"
    )  # Get task ID for logging

    event_loop_stored = False
    current_loop = asyncio.get_running_loop()
    last_event = None  # To track the last event from the runner

    async for event in component.runner.run_async(
        user_id=adk_session.user_id,
        session_id=adk_session.id,
        new_message=adk_content,
        run_config=run_config,
    ):
        last_event = event  # Keep track of the last event
        if not event_loop_stored and event.invocation_id:
            component.store_task_event_loop(event.invocation_id, current_loop)
            event_loop_stored = True

        # --- Check for cancellation at the beginning of each event processing cycle ---
        if cancellation_event.is_set():
            log.info(
                "%s Task %s cancellation detected during ADK event processing loop.",
                component.log_identifier,
                logical_task_id,
            )
            if (
                hasattr(component.runner, "_invocation_context")
                and component.runner._invocation_context
            ):
                component.runner._invocation_context.end_invocation = True
                log.info(
                    "%s Set end_invocation=True for ADK task %s.",
                    component.log_identifier,
                    logical_task_id,
                )
            raise TaskCancelledError(
                f"Task {logical_task_id} was cancelled by signal during ADK event processing."
            )

        # --- Process ADK Event (includes potential tool calls/responses) ---
        # Check for cancellation *before* processing the event which might trigger tool calls
        if cancellation_event.is_set():
            log.info(
                "%s Task %s cancellation detected before processing ADK event %s.",
                component.log_identifier,
                logical_task_id,
                event.id,
            )
            if (
                hasattr(component.runner, "_invocation_context")
                and component.runner._invocation_context
            ):
                component.runner._invocation_context.end_invocation = True
            raise TaskCancelledError(
                f"Task {logical_task_id} was cancelled before processing ADK event {event.id}."
            )

        # --- Track PeerAgentTool Invocation ---
        if event.content and event.content.parts:
            for part in event.content.parts:
                if part.function_call:
                    pass  # Placeholder for more specific pre-tool call logic if needed

        try:
            await component.process_and_publish_adk_event(event, a2a_context)
        except Exception as process_err:
            # Log error but continue processing ADK events if possible
            log.exception(
                "%s Error processing intermediate ADK event %s for task %s: %s",
                component.log_identifier,
                event.id,
                logical_task_id,
                process_err,
            )

        # --- Check for cancellation *after* processing the event (tool might have run) ---
        if cancellation_event.is_set():
            log.info(
                "%s Task %s cancellation detected after processing ADK event %s.",
                component.log_identifier,
                logical_task_id,
                event.id,
            )
            if (
                hasattr(component.runner, "_invocation_context")
                and component.runner._invocation_context
            ):
                component.runner._invocation_context.end_invocation = True
            raise TaskCancelledError(
                f"Task {logical_task_id} was cancelled after processing ADK event {event.id}."
            )

        # --- Clean up PeerAgentTool Tracking if it was a function_response from one ---
        if event.content and event.content.parts:
            for part in event.content.parts:
                if part.function_response:
                    if part.function_response.name.startswith("peer_"):  # Heuristic
                        with component.active_peer_sub_tasks_lock:
                            if component.active_peer_sub_tasks.pop(
                                logical_task_id, None
                            ):
                                log.info(
                                    "%s Cleared peer sub-task tracking for main task %s after tool response for %s.",
                                    component.log_identifier,
                                    logical_task_id,
                                    part.function_response.name,
                                )

    # --- Finalization Logic ---
    # Before finalizing, one last check for cancellation
    if cancellation_event.is_set():
        log.info(
            "%s Task %s cancellation detected before finalization.",
            component.log_identifier,
            logical_task_id,
        )
        if (
            hasattr(component.runner, "_invocation_context")
            and component.runner._invocation_context
        ):
            component.runner._invocation_context.end_invocation = True
        raise TaskCancelledError(
            f"Task {logical_task_id} was cancelled before finalization."
        )

    # Check if the last event from the ADK run was a long-running tool call.
    # If so, the task is paused, not completed.
    if last_event and last_event.long_running_tool_ids:
        log.info(
            "%s ADK run completed by invoking a long-running tool. Task %s will remain open, awaiting peer response.",
            component.log_identifier,
            logical_task_id,
        )
        return True  # Signal that the task is paused

    # If we reach here, the task is truly complete.
    log.debug(
        "%s ADK run_async completed for task %s. Calling success finalizer.",
        component.log_identifier,
        logical_task_id,
    )
    try:
        await component.finalize_task_success(a2a_context)
    except Exception as finalize_err:
        log.exception(
            "%s Critical error during finalize_task_success for task %s: %s",
            component.log_identifier,
            logical_task_id,
            finalize_err,
        )
        # Re-raise to ensure the wrapper's finally block still runs for cleanup
        raise

    return False # Signal that the task is finished
