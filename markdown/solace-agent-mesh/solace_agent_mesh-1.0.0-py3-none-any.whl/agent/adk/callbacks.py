# src/agent/adk/callbacks.py
"""
ADK Callbacks for the A2A Host Component.
Includes dynamic instruction injection, artifact metadata injection,
embed resolution, and logging.
"""
import asyncio
import json
import functools
from typing import Any, Dict, Optional, TYPE_CHECKING, Set, List, Tuple
from collections import defaultdict

from google.adk.tools import BaseTool, ToolContext
from google.adk.artifacts import BaseArtifactService
from google.adk.agents.callback_context import CallbackContext
from google.adk.models.llm_request import LlmRequest
from google.adk.models.llm_response import LlmResponse
from google.genai import types as adk_types
from solace_ai_connector.common.log import log

# Import helpers from the new module (Absolute imports from src/)
from ...agent.utils.artifact_helpers import (
    METADATA_SUFFIX,
    format_metadata_for_llm,
)
from ...agent.utils.context_helpers import get_original_session_id
from ..tools.tool_definition import BuiltinTool


def create_dangling_tool_call_repair_content(
    dangling_calls: List[adk_types.FunctionCall], error_message: str
) -> adk_types.Content:
    """
    Creates a synthetic ADK Content object to repair a dangling tool call.

    Args:
        dangling_calls: The list of FunctionCall objects that need a response.
        error_message: The error message to include in the response.

    Returns:
        An ADK Content object with role='user' containing the error response.
    """
    error_response_parts = []
    for fc in dangling_calls:
        error_response_part = adk_types.Part.from_function_response(
            name=fc.name,
            response={"status": "error", "message": error_message},
        )
        # Correlate the response to the call by setting the ID
        error_response_part.function_response.id = fc.id
        error_response_parts.append(error_response_part)

    return adk_types.Content(role="user", parts=error_response_parts)


def repair_history_callback(
    callback_context: CallbackContext, llm_request: LlmRequest
) -> Optional[LlmResponse]:
    """
    ADK before_model_callback to proactively check for and repair dangling
    tool calls in the conversation history before it's sent to the LLM.
    This acts as a "suspender" to catch any history corruption.
    """
    log_identifier = "[Callback:RepairHistory]"
    if not llm_request.contents:
        return None

    history_modified = False
    # Use a while loop to allow restarting the check if a modification is made
    i = 0
    while i < len(llm_request.contents):
        content = llm_request.contents[i]
        # Check for a model turn that is calling a tool
        function_calls = []
        if content.role == "model" and content.parts:
            function_calls = [p.function_call for p in content.parts if p.function_call]

        if function_calls:
            # This is a model turn with a tool call. Now, check the NEXT turn.
            next_content_is_valid_response = False
            if (i + 1) < len(llm_request.contents):
                next_content = llm_request.contents[i + 1]
                # The next turn MUST be a 'user' turn with a function response.
                if (
                    next_content.role == "user"
                    and next_content.parts
                    and any(p.function_response for p in next_content.parts)
                ):
                    next_content_is_valid_response = True

            if not next_content_is_valid_response:
                log.warning(
                    "%s Found dangling tool call in history for tool(s): %s. Repairing.",
                    log_identifier,
                    [fc.name for fc in function_calls],
                )
                repair_content = create_dangling_tool_call_repair_content(
                    dangling_calls=function_calls,
                    error_message="The previous tool call did not complete successfully and was automatically repaired.",
                )
                # Insert the repair content immediately after the dangling call
                llm_request.contents.insert(i + 1, repair_content)
                history_modified = True
                # Skip the newly inserted item and continue check from the next one
                i += 1
        i += 1

    if history_modified:
        log.info(
            "%s History was modified to repair dangling tool calls.", log_identifier
        )

    return None


# Import from the new embeds structure
from ...common.utils.embeds import (
    EMBED_DELIMITER_OPEN,
    EMBED_DELIMITER_CLOSE,
)

# Task 2.2: Import MCPTool
from google.adk.tools.mcp_tool import MCPTool

# json is already imported
# solace_ai_connector.common.log.log is already imported as `log`
from ...common.utils.embeds import (  # This line was missing the import target
    EMBED_CHAIN_DELIMITER,
)

# Import MODIFIER_IMPLEMENTATIONS from the new location
from ...common.utils.embeds.modifiers import MODIFIER_IMPLEMENTATIONS

# Imports for notify_tool_invocation_start_callback
from google.adk.tools import BaseTool, ToolContext
from typing import Dict, Any, Optional, TYPE_CHECKING
from datetime import datetime

# json is already imported
# solace_ai_connector.common.log.log is already imported as `log`

if TYPE_CHECKING:
    from ..sac.component import SamAgentComponent  # Corrected relative import

from ...common.types import (  # Corrected relative import
    TaskStatusUpdateEvent,
    TaskStatus,
    TaskState,
    Message as A2AMessage,
    TextPart,
    JSONRPCResponse,
)
from ...common.a2a_protocol import get_gateway_status_topic  # Corrected relative import


# Task 2.1: Import necessary modules for _save_mcp_response_as_artifact
import uuid
from datetime import datetime, timezone
from ...agent.utils.artifact_helpers import (
    save_artifact_with_metadata,
    DEFAULT_SCHEMA_MAX_KEYS,
)


METADATA_RESPONSE_KEY = "appended_artifact_metadata"


# Task 2.1: Implement _save_mcp_response_as_artifact Helper Function
async def _save_mcp_response_as_artifact(
    tool: BaseTool,
    tool_context: ToolContext,
    host_component: "SamAgentComponent",
    mcp_response_dict: Dict[str, Any],
    original_tool_args: Dict[str, Any],
) -> Dict[str, Any]:  # Returns a dictionary with saved artifact details
    """
    Saves the full MCP tool response as a JSON artifact with associated metadata.

    Args:
        tool: The MCPTool instance that generated the response.
        tool_context: The ADK ToolContext.
        host_component: The A2A_ADK_HostComponent instance for accessing config and services.
        mcp_response_dict: The raw MCP tool response dictionary.
        original_tool_args: The original arguments passed to the MCP tool.

    Returns:
        A dictionary containing details of the saved artifact (filename, version, etc.),
        as returned by `save_artifact_with_metadata`.
    """
    log_identifier = f"[CallbackHelper:{tool.name}]"
    log.debug("%s Saving MCP response as artifact...", log_identifier)

    try:
        # 1. Generate Filename (R2.4)
        a2a_context = tool_context.state.get("a2a_context", {})
        logical_task_id = a2a_context.get("logical_task_id", "unknownTask")
        task_id_suffix = logical_task_id[-6:]
        random_suffix = uuid.uuid4().hex[:6]
        filename = f"{task_id_suffix}_{tool.name}_{random_suffix}.json"
        log.debug("%s Generated artifact filename: %s", log_identifier, filename)

        # 2. Prepare Content and Metadata (R2.5)
        content_bytes = json.dumps(mcp_response_dict, indent=2).encode("utf-8")
        mime_type = "application/json"
        # Use current UTC time for the artifact timestamp
        artifact_timestamp = datetime.now(timezone.utc)

        metadata_for_saving = {
            "description": f"Full JSON response from MCP tool {tool.name}.",
            "source_tool_name": tool.name,
            "source_tool_args": original_tool_args,
            # Add any other relevant metadata from tool_context or host_component if needed
        }
        log.debug("%s Prepared content and metadata for saving.", log_identifier)

        # 3. Call save_artifact_with_metadata
        artifact_service = host_component.artifact_service
        if not artifact_service:
            raise ValueError("ArtifactService is not available on host_component.")

        app_name = (
            host_component.agent_name
        )  # ADK agent name is the app_name for ADK services
        user_id = tool_context._invocation_context.user_id
        session_id = get_original_session_id(tool_context._invocation_context)
        schema_max_keys = host_component.get_config(
            "schema_max_keys", DEFAULT_SCHEMA_MAX_KEYS
        )

        log.debug(
            "%s Calling save_artifact_with_metadata with: app_name=%s, user_id=%s, session_id=%s, filename=%s, schema_max_keys=%d",
            log_identifier,
            app_name,
            user_id,
            session_id,
            filename,
            schema_max_keys,
        )

        save_result = await save_artifact_with_metadata(
            artifact_service=artifact_service,
            app_name=app_name,
            user_id=user_id,
            session_id=session_id,
            filename=filename,
            content_bytes=content_bytes,
            mime_type=mime_type,
            metadata_dict=metadata_for_saving,
            timestamp=artifact_timestamp,
            schema_max_keys=schema_max_keys,
        )

        log.info(
            "%s MCP response saved as artifact '%s' (version %s). Result: %s",
            log_identifier,
            save_result.get("data_filename", filename),
            save_result.get("data_version", "N/A"),
            save_result.get("status"),
        )
        return save_result

    except Exception as e:
        log.exception(
            "%s Error in _save_mcp_response_as_artifact: %s", log_identifier, e
        )
        # Return a dictionary indicating failure, consistent with save_artifact_with_metadata's error structure
        return {
            "status": "error",
            "data_filename": filename if "filename" in locals() else "unknown_filename",
            "message": f"Failed to save MCP response as artifact: {e}",
        }


# Task 2.2: Implement manage_large_mcp_tool_responses_callback Function
async def manage_large_mcp_tool_responses_callback(
    tool: BaseTool,
    args: Dict[str, Any],
    tool_context: ToolContext,
    tool_response: Any,  # Changed from Dict to Any to reflect actual ADK behavior
    host_component: "SamAgentComponent",
) -> Optional[Dict[str, Any]]:
    """
    Manages large responses from MCP tools by conditionally saving them as artifacts
    and/or truncating them before returning to the LLM.
    The 'tool_response' is the direct output from the tool's run_async method.
    """
    log_identifier = f"[Callback:ManageLargeMCPResponse:{tool.name}]"
    log.info(
        "%s Starting callback for tool response, type: %s",
        log_identifier,
        type(tool_response).__name__,
    )

    if tool_response is None:
        return None

    # Step 1: Identify MCP Tool
    if not isinstance(tool, MCPTool):
        log.debug(
            "%s Tool is not an MCPTool. Skipping large response handling.",
            log_identifier,
        )
        # If tool_response is not a dict already, ADK framework will wrap it later.
        # For non-MCP tools, we assume it's either a dict or a serializable type.
        return (
            tool_response
            if isinstance(tool_response, dict)
            else {"result": tool_response}
        )

    log.debug(
        "%s Tool is an MCPTool. Proceeding with large response handling.",
        log_identifier,
    )

    # Convert MCPTool's Pydantic model response to a dictionary
    if hasattr(tool_response, "model_dump"):
        mcp_response_dict = tool_response.model_dump(exclude_none=True)
        log.debug("%s Converted MCPTool response object to dictionary.", log_identifier)
    elif isinstance(tool_response, dict):
        mcp_response_dict = tool_response  # Already a dict, use as is
        log.debug("%s MCPTool response is already a dictionary.", log_identifier)
    else:
        log.warning(
            "%s MCPTool response is not a Pydantic model or dict (type: %s). Attempting to proceed, but serialization might fail.",
            log_identifier,
            type(tool_response),
        )
        # Attempt to treat it as if it were a dict; json.dumps might handle some objects.
        # This is a fallback and might not be robust.
        mcp_response_dict = tool_response

    # Step 2: Retrieve Configuration
    try:
        save_threshold = host_component.get_config(
            "mcp_tool_response_save_threshold_bytes", 2048
        )
        llm_max_bytes = host_component.get_config("mcp_tool_llm_return_max_bytes", 4096)
        log.debug(
            "%s Config: save_threshold=%d bytes, llm_max_bytes=%d bytes.",
            log_identifier,
            save_threshold,
            llm_max_bytes,
        )
    except Exception as e:
        log.error(
            "%s Error retrieving configuration: %s. Using defaults.", log_identifier, e
        )
        save_threshold = 2048
        llm_max_bytes = 4096

    # Step 3: Serialize and Size Original Response
    try:
        # Use mcp_response_dict for serialization
        serialized_original_response_str = json.dumps(mcp_response_dict)
        original_response_bytes = len(serialized_original_response_str.encode("utf-8"))
        log.debug(
            "%s Original response size: %d bytes.",
            log_identifier,
            original_response_bytes,
        )
    except TypeError as e:
        log.error(
            "%s Failed to serialize original MCP tool response dictionary: %s. Returning original response object.",
            log_identifier,
            e,
        )
        return tool_response  # Return the original object if dict conversion/serialization fails

    # Step 4: Determine Truncation and Save Conditions
    needs_truncation_for_llm = original_response_bytes > llm_max_bytes
    needs_saving_as_artifact = (
        original_response_bytes > save_threshold
    ) or needs_truncation_for_llm
    log.debug(
        "%s Conditions: needs_truncation_for_llm=%s, needs_saving_as_artifact=%s",
        log_identifier,
        needs_truncation_for_llm,
        needs_saving_as_artifact,
    )

    # Step 5: Save Artifact if Needed
    saved_artifact_details = None
    if needs_saving_as_artifact:
        log.info(
            "%s Original response (%d bytes) requires saving (save_threshold=%d, llm_max_bytes=%d). Saving as artifact.",
            log_identifier,
            original_response_bytes,
            save_threshold,
            llm_max_bytes,
        )
        # Call the now synchronous helper directly
        saved_artifact_details = await _save_mcp_response_as_artifact(
            tool, tool_context, host_component, mcp_response_dict, args
        )
        if not (
            saved_artifact_details.get("status") == "success"
            or saved_artifact_details.get("status") == "partial_success"
        ):
            log.warning(
                "%s Failed to save artifact: %s. Proceeding without saved artifact details.",
                log_identifier,
                saved_artifact_details.get("message"),
            )
            # Keep saved_artifact_details as it contains error info

    # Step 6: Prepare LLM Output and Message
    final_llm_response_dict: Dict[str, Any] = {}
    message_parts_for_llm: list[str] = []

    # 6.1: Determine mcp_tool_output (truncated or full)
    if needs_truncation_for_llm:
        # Truncate the original serialized JSON string
        # Max bytes for the string itself, not including the suffix
        truncation_suffix = "... [Response truncated due to size limit.]"
        adjusted_max_bytes = llm_max_bytes - len(truncation_suffix.encode("utf-8"))
        if adjusted_max_bytes < 0:
            adjusted_max_bytes = (
                0  # handle edge case where suffix is larger than max_bytes
            )

        truncated_bytes = serialized_original_response_str.encode("utf-8")[
            :adjusted_max_bytes
        ]
        truncated_preview_str = (
            truncated_bytes.decode("utf-8", "ignore") + truncation_suffix
        )

        final_llm_response_dict["mcp_tool_output"] = {
            "type": "truncated_json_string",
            "content": truncated_preview_str,
        }
        message_parts_for_llm.append(
            f"The response from tool '{tool.name}' was too large ({original_response_bytes} bytes) for direct display and has been truncated."
        )
        log.debug("%s MCP tool output truncated for LLM.", log_identifier)
    else:
        final_llm_response_dict["mcp_tool_output"] = (
            mcp_response_dict  # Full original dict
        )
        log.debug(
            "%s MCP tool output is the full original response for LLM.", log_identifier
        )

    # 6.2: Add artifact information if saved
    if needs_saving_as_artifact:
        if saved_artifact_details and (
            saved_artifact_details.get("status") == "success"
            or saved_artifact_details.get("status") == "partial_success"
        ):
            final_llm_response_dict["saved_mcp_response_artifact_details"] = (
                saved_artifact_details
            )
            filename = saved_artifact_details.get(
                "data_filename", "unknown_artifact.json"
            )
            version = saved_artifact_details.get("data_version", "N/A")
            message_parts_for_llm.append(
                f"The full response has been saved as artifact '{filename}' (version {version})."
            )
            log.debug(
                "%s Added saved artifact details to LLM response.", log_identifier
            )
        else:  # Save was needed but failed
            message_parts_for_llm.append(
                "Saving the full response as an artifact failed."
            )
            final_llm_response_dict["saved_mcp_response_artifact_details"] = {
                "status": "error",
                "message": saved_artifact_details.get(
                    "message", "Artifact saving failed."
                ),
                "filename": saved_artifact_details.get("data_filename", "unknown"),
            }
            log.warning(
                "%s Artifact save failed, error details included in LLM response.",
                log_identifier,
            )

    # 6.3: Determine overall status
    if needs_saving_as_artifact and (
        saved_artifact_details.get("status") == "success"
        or saved_artifact_details.get("status") == "partial_success"
    ):
        if needs_truncation_for_llm:
            final_llm_response_dict["status"] = "processed_saved_and_truncated"
        else:
            final_llm_response_dict["status"] = "processed_and_saved"
    elif needs_saving_as_artifact:  # Save failed
        if needs_truncation_for_llm:
            final_llm_response_dict["status"] = "processed_truncated_save_failed"
        else:
            final_llm_response_dict["status"] = "processed_save_failed"
    elif (
        needs_truncation_for_llm
    ):  # Should not happen if save logic is correct (truncation implies save)
        final_llm_response_dict["status"] = "processed_truncated"  # Fallback
    else:
        final_llm_response_dict["status"] = "processed"

    # 6.4: Construct final message_to_llm
    if not message_parts_for_llm:
        message_parts_for_llm.append(f"Response from tool '{tool.name}' processed.")
    final_llm_response_dict["message_to_llm"] = " ".join(message_parts_for_llm)

    # Step 7: Return final_llm_response_dict
    log.info(
        "%s Returning processed response for LLM. Final status: %s",
        log_identifier,
        final_llm_response_dict.get("status", "unknown"),
    )
    return final_llm_response_dict


def _generate_embed_instruction(
    include_artifact_content: bool,
    log_identifier: str,
) -> Optional[str]:
    """Generates the instruction text for using embeds."""
    open_delim = EMBED_DELIMITER_OPEN
    close_delim = EMBED_DELIMITER_CLOSE
    chain_delim = EMBED_CHAIN_DELIMITER
    early_types = "`math`, `datetime`, `uuid`, `artifact_meta`"
    modifier_list = ", ".join(
        [f"`{prefix}`" for prefix in MODIFIER_IMPLEMENTATIONS.keys()]
    )

    base_instruction = f"""\
You can use dynamic embeds in your text responses and tool parameters using the syntax {open_delim}type:expression {chain_delim} format{close_delim}. This allows you to
always have correct information in your output. Specifically, make sure you always use embeds for math, even if it is simple. You will make mistakes if you try to do math yourself.
Use HTML entities to escape the delimiters.
This host resolves the following embed types *early* (before sending to the LLM or tool): {early_types}. This means the embed is replaced with its resolved value.
- `{open_delim}math:expression | .2f{close_delim}`: Evaluates the math expression using asteval - this must just be plain math (plus random(), randint() and uniform()), don't import anything. Optional format specifier follows Python's format(). Use this for all math calculations rather than doing it yourself. Don't give approximations.
- `{open_delim}datetime:format_or_keyword{close_delim}`: Inserts current date/time. Use Python strftime format (e.g., `%Y-%m-%d`) or keywords (`iso`, `timestamp`, `date`, `time`, `now`).
- `{open_delim}uuid:{close_delim}`: Inserts a random UUID.
- `{open_delim}artifact_meta:filename[:version]{close_delim}`: Inserts a summary of the artifact's metadata (latest version if unspecified).
- `{open_delim}status_update:Your message here{close_delim}`: Generates an immediate, distinct status message event that is displayed to the user (e.g., 'Thinking...', 'Searching database...'). This message appears in a status area, not as part of the main chat conversation. Use this to provide interim feedback during processing."""

    artifact_content_instruction = f"""
- `{open_delim}artifact_content:filename[:version] {chain_delim} modifier1:value1 {chain_delim} ... {chain_delim} format:output_format{close_delim}`: Embeds artifact content after applying a chain of modifiers. This is resolved *late* (typically by a gateway before final display).
    - Use `{chain_delim}` to separate the artifact identifier from the modifier steps and the final format step.
    - Available modifiers: {modifier_list}.
    - The `format:output_format` step *must* be the last step in the chain. Supported formats include `text`, `datauri`, `json`, `json_pretty`, `csv`, `html`. Formatting as datauri, will include the data URI prefix, so do not add it yourself.
    - Use `artifact_meta` first to check size; embedding large files may fail.
    - **Using `apply_to_template` Modifier:**
        - This modifier renders a Mustache template artifact using the data from the previous step.
        - **Data Context:**
            - If the input data's original MIME type was `text/csv` or `application/csv`, it's automatically parsed into an object with two keys: `headers` (a list of column name strings) and `data_rows` (a list of lists, where each inner list contains the string values for a row). Example template usage: `<thead><tr>{{{{#headers}}}}<th>{{{{.}}}}</th>{{{{/headers}}}}</tr></thead><tbody>{{{{#data_rows}}}}<tr>{{{{#.}}}}<td>{{{{.}}}}</td>{{{{/.}}}}</tr>{{{{/data_rows}}}}</tbody>`. If CSV parsing fails, the raw string content is available under `text`.
            - If the input data is a **list** (e.g., from `jsonpath` or a JSON array), it's available under `items`.
            - If the input data is a **dictionary** (e.g., from a JSON object), its keys are directly available (e.g., `{{{{key1}}}}`).
            - If the input data is a **plain string** (and not auto-parsed as CSV), it's available under `text`.
        - The template filename can include a version (e.g., `template.mustache:2`). Defaults to latest.
        - The template itself can contain `«artifact_content:...»` embeds, which will be resolved before rendering.
    - Examples:
        - `<img src="{open_delim}artifact_content:image.png {chain_delim} format:datauri{close_delim}`"> (Embed image as data URI - NOTE that this includes the datauri prefix. Do not add it yourself.)
        - `{open_delim}artifact_content:data.json {chain_delim} jsonpath:$.items[*] {chain_delim} select_fields:name,status {chain_delim} format:json_pretty{close_delim}` (Extract and format JSON fields)
        - `{open_delim}artifact_content:logs.txt {chain_delim} grep:ERROR {chain_delim} head:10 {chain_delim} format:text{close_delim}` (Get first 10 error lines)
        - `{open_delim}artifact_content:products.csv {chain_delim} apply_to_template:product_table.html.mustache {chain_delim} format:html{close_delim}` (CSV is auto-parsed to `headers` and `data_rows` for the HTML template)
        - `{open_delim}artifact_content:config.json {chain_delim} jsonpath:$.userPreferences.theme {chain_delim} format:text{close_delim}` (Extract a single value from a JSON artifact)
        - `{open_delim}artifact_content:sensor_readings.csv {chain_delim} filter_rows_eq:status:critical {chain_delim} select_cols:timestamp,sensor_id,value {chain_delim} format:csv{close_delim}` (Filter critical sensor readings and select specific columns, output as CSV)
        - `{open_delim}artifact_content:server.log {chain_delim} tail:100 {chain_delim} grep:WARN {chain_delim} format:text{close_delim}` (Get warning lines from the last 100 lines of a log file)"""

    final_instruction = base_instruction
    if include_artifact_content:
        final_instruction += artifact_content_instruction

    final_instruction += f"""
Ensure the syntax is exactly `{open_delim}type:expression{close_delim}` or `{open_delim}type:expression {chain_delim} ... {chain_delim} format:output_format{close_delim}` with no extra spaces around delimiters (`{open_delim}`, `{close_delim}`, `{chain_delim}`, `:`, `|`). Malformed directives will be ignored."""

    return final_instruction


def _generate_tool_instructions_from_registry(
    active_tools: List[BuiltinTool],
    log_identifier: str,
) -> str:
    """Generates instruction text from a list of BuiltinTool definitions."""
    if not active_tools:
        return ""

    instructions_by_category = defaultdict(list)
    for tool in sorted(active_tools, key=lambda t: (t.category, t.name)):
        # Format the tool's signature
        param_parts = []
        if tool.parameters and tool.parameters.properties:
            for name, schema in tool.parameters.properties.items():
                is_optional = name not in (tool.parameters.required or [])
                # Attempt to get type, default to 'any'
                type_name = "any"
                if schema and hasattr(schema, "type") and schema.type:
                    type_name = schema.type.name.lower()

                param_str = f"{name}: {type_name}"
                if is_optional:
                    # This is a simplification; real optionality might be more complex
                    # For prompt purposes, this is likely sufficient.
                    param_str = f"Optional[{param_str}]"
                param_parts.append(param_str)

        signature = f"`{tool.name}({', '.join(param_parts)})`"
        description = tool.description or "No description available."

        instructions_by_category[tool.category].append(f"- {signature}: {description}")

    full_instruction_list = []
    for category, tool_instructions in sorted(instructions_by_category.items()):
        # Format category name for display (e.g., 'data_analysis' -> 'Data Analysis')
        category_display_name = category.replace("_", " ").title()
        full_instruction_list.append(
            f"You have access to the following '{category_display_name}' tools:"
        )
        full_instruction_list.extend(tool_instructions)

    return "\n".join(full_instruction_list)


# --- Callback Function for Instruction Injection ---
def inject_dynamic_instructions_callback(
    callback_context: CallbackContext,
    llm_request: LlmRequest,
    host_component: "SamAgentComponent",
    active_builtin_tools: List[BuiltinTool],
) -> Optional[LlmResponse]:
    """
    ADK before_model_callback to inject instructions based on host config.
    Modifies the llm_request directly.
    """
    log_identifier = "[Callback:InjectInstructions]"
    log.debug("%s Running instruction injection callback...", log_identifier)

    if not host_component:
        log.error(
            "%s Host component instance not provided. Cannot inject instructions.",
            log_identifier,
        )
        return None

    injected_instructions = []

    # --- Planning Instructions (Hardcoded) ---
    planning_instruction = """\
Parallel Tool Calling:
The system is capable of calling multiple tools in parallel to speed up processing. Please try to run tools in parallel when they don't depend on each other.

Embeds in responses from agents:
To be efficient, agents may response with artifact_content embeds in their responses. These will not be resolved until they are sent back to a gateway. If it makes
sense, just carry that embed forward to your response to the user. For example, if you ask for an org chart from another agent and its response contains an embed like
`{open_delim}artifact_content:org_chart.md{close_delim}`, you can just include that embed in your response to the user. The gateway will resolve it and display the org chart.

When faced with a complex goal or request that involves multiple steps, data retrieval, or artifact summarization to produce a new report or document, you MUST first create a plan.
Simple, direct requests like 'create an image of a dog' or 'write an email to thank my boss' do not require a plan.

If a plan is created:
1. It should be a terse, hierarchical list describing the steps needed.
2. Use '☐' (empty checkbox emoji) for pending items and '☑' (checked checkbox emoji) for completed items.
3. If the plan changes significantly during execution, restate the updated plan.
4. As items are completed, update the plan to check them off.

"""
    injected_instructions.append(planning_instruction)
    log.debug("%s Added hardcoded planning instructions.", log_identifier)
    # --- End Planning Instructions ---

    # --- 1. Process Agent-Provided System Instructions ---
    agent_instruction_str: Optional[str] = None
    if host_component._agent_system_instruction_callback:
        log.debug(
            "%s Calling agent-provided system instruction callback.", log_identifier
        )
        try:
            agent_instruction_str = host_component._agent_system_instruction_callback(
                callback_context, llm_request
            )
            if agent_instruction_str and isinstance(agent_instruction_str, str):
                injected_instructions.append(agent_instruction_str)
                log.info(
                    "%s Injected instructions from agent callback.", log_identifier
                )
            elif agent_instruction_str:  # Not a string
                log.warning(
                    "%s Agent instruction callback returned non-string type: %s. Ignoring.",
                    log_identifier,
                    type(agent_instruction_str),
                )
        except Exception as e_cb:
            log.error(
                "%s Error in agent-provided system instruction callback: %s. Skipping.",
                log_identifier,
                e_cb,
            )
    # Allow both static string and callback to contribute if both are set.
    if host_component._agent_system_instruction_string:
        log.debug(
            "%s Using agent-provided static system instruction string.", log_identifier
        )
        agent_instruction_str = host_component._agent_system_instruction_string
        if agent_instruction_str and isinstance(agent_instruction_str, str):
            injected_instructions.append(agent_instruction_str)
            log.info("%s Injected static instructions from agent.", log_identifier)

    # Print out the contents from:
    # contents=[Content(parts=[Part(video_metadata=None, thought=None, code_execution_result=None, executable_code=None, file_data=None, function_call=None, function_response=None, inline_data=None, text='hi')], role='user')]
    contents = llm_request.contents
    if contents:
        log.debug(f"\n\n### LLM Request Contents ###")
        for content in contents:
            if content.parts:
                for part in content.parts:
                    if part.text:
                        log.debug("Content part: %s", part.text)
                    elif part.function_call:
                        log.debug("Function call: %s", part.function_call.name)
                    elif part.function_response:
                        log.debug("Function response: %s", part.function_response)
                    else:
                        log.debug("raw: %s", part)
        log.debug(f"### End LLM Request Contents ###\n\n")

    # --- 2. Process Host-Provided Dynamic Instructions (Embeds, Tools, etc.) ---
    # Embed Instructions
    if host_component.get_config("enable_embed_resolution", True):
        include_artifact_content_instr = host_component.get_config(
            "enable_artifact_content_instruction", True
        )
        instruction = _generate_embed_instruction(
            include_artifact_content_instr, log_identifier
        )
        if instruction:
            injected_instructions.append(instruction)
            log.debug(
                "%s Prepared embed instructions (artifact_content included: %s).",
                log_identifier,
                include_artifact_content_instr,
            )

    # --- Generate Built-in Tool Instructions from Registry ---
    if active_builtin_tools:
        instruction = _generate_tool_instructions_from_registry(
            active_builtin_tools, log_identifier
        )
        if instruction:
            injected_instructions.append(instruction)
            log.debug(
                "%s Prepared instructions for %d active built-in tools.",
                log_identifier,
                len(active_builtin_tools),
            )

    # Peer Discovery Instructions (from callback state)
    peer_instructions = callback_context.state.get("peer_tool_instructions")
    if peer_instructions and isinstance(peer_instructions, str):
        injected_instructions.append(peer_instructions)
        log.debug(
            "%s Injected peer discovery instructions from callback state.",
            log_identifier,
        )

    # --- Last LLM Call Notification ---
    last_call_notification_message_added = False
    try:
        invocation_context = callback_context._invocation_context
        if invocation_context and invocation_context.run_config:
            current_llm_calls = (
                invocation_context._invocation_cost_manager._number_of_llm_calls
            )
            max_llm_calls = invocation_context.run_config.max_llm_calls

            log.debug(
                "%s Checking for last LLM call: current_calls=%d, max_calls=%s",
                log_identifier,
                current_llm_calls,
                max_llm_calls,
            )

            if (
                max_llm_calls
                and max_llm_calls > 0
                and current_llm_calls
                >= (max_llm_calls - 1)  # ADK increments before this callback
            ):
                last_call_text = (
                    "IMPORTANT: This is your final allowed interaction for the current request. "
                    "Please inform the user that to continue this line of inquiry, they will need to "
                    "make a new request or explicitly ask to continue if the interface supports it. "
                    "Summarize your current findings and conclude your response."
                )
                # Add as a new 'model' role message to llm_request.contents
                if llm_request.contents is None:
                    llm_request.contents = []

                last_call_content = adk_types.Content(
                    role="model",  # Using 'model' role for internal directive
                    parts=[adk_types.Part(text=last_call_text)],
                )
                llm_request.contents.append(last_call_content)
                last_call_notification_message_added = True
                log.info(
                    "%s Added 'last LLM call' notification as a 'model' message to llm_request.contents. Current calls (%d) reached max_llm_calls (%d).",
                    log_identifier,
                    current_llm_calls,
                    max_llm_calls,
                )
    except Exception as e_last_call:
        log.error(
            "%s Error checking/injecting last LLM call notification message: %s",
            log_identifier,
            e_last_call,
        )
    # --- End Last LLM Call Notification ---

    # Append other instructions to system_instruction
    if injected_instructions:
        combined_instructions = "\n\n---\n\n".join(injected_instructions)
        if llm_request.config is None:
            log.warning(
                "%s llm_request.config is None, cannot append system instructions.",
                log_identifier,
            )
        else:
            if llm_request.config.system_instruction is None:
                llm_request.config.system_instruction = ""

            if llm_request.config.system_instruction:
                llm_request.config.system_instruction += (
                    "\n\n---\n\n" + combined_instructions
                )
            else:
                llm_request.config.system_instruction = combined_instructions
            log.info(
                "%s Injected %d dynamic instruction block(s) into llm_request.config.system_instruction.",
                log_identifier,
                len(injected_instructions),
            )
    elif (
        not last_call_notification_message_added
    ):  # Only log "no instructions" if neither type was added
        log.debug(
            "%s No dynamic instructions (system or last_call message) were injected based on config.",
            log_identifier,
        )

    return None


# --- Callback Function for Metadata Injection ---
async def after_tool_callback_inject_metadata(
    tool: BaseTool,
    args: Dict,
    tool_context: ToolContext,
    tool_response: Dict,
    host_component: "SamAgentComponent",
) -> Optional[Dict]:
    """
    ADK after_tool_callback to automatically load and inject metadata for
    newly created artifacts into the tool's response dictionary.
    """
    log_identifier = f"[Callback:InjectMetadata:{tool.name}]"
    log.info(
        "%s Starting metadata injection for tool response, type: %s",
        log_identifier,
        type(tool_response).__name__,
    )

    if not host_component:
        log.error(
            "%s Host component instance not provided. Cannot proceed.",
            log_identifier,
        )
        return None

    if not tool_context.actions.artifact_delta:
        log.debug(
            "%s No artifact delta found. Skipping metadata injection.", log_identifier
        )
        return None

    artifact_service: Optional[BaseArtifactService] = (
        tool_context._invocation_context.artifact_service
    )
    if not artifact_service:
        log.error(
            "%s ArtifactService not available. Cannot load metadata.",
            log_identifier,
        )
        return None

    app_name = tool_context._invocation_context.app_name
    user_id = tool_context._invocation_context.user_id
    session_id = get_original_session_id(tool_context._invocation_context)

    metadata_texts = []

    for filename, version in tool_context.actions.artifact_delta.items():
        if filename.endswith(METADATA_SUFFIX):
            log.debug(
                "%s Skipping metadata artifact '%s' itself.", log_identifier, filename
            )
            continue

        metadata_filename = f"{filename}{METADATA_SUFFIX}"
        log.debug(
            "%s Found data artifact '%s' v%d. Attempting to load metadata '%s' v%d.",
            log_identifier,
            filename,
            version,
            metadata_filename,
            version,
        )

        try:
            metadata_part = await artifact_service.load_artifact(
                app_name=app_name,
                user_id=user_id,
                session_id=session_id,
                filename=metadata_filename,
                version=version,
            )

            if metadata_part and metadata_part.inline_data:
                try:
                    metadata_dict = json.loads(
                        metadata_part.inline_data.data.decode("utf-8")
                    )
                    metadata_dict["version"] = version
                    formatted_text = format_metadata_for_llm(metadata_dict)
                    metadata_texts.append(formatted_text)
                    log.info(
                        "%s Successfully loaded and formatted metadata for '%s' v%d.",
                        log_identifier,
                        filename,
                        version,
                    )
                except json.JSONDecodeError as json_err:
                    log.warning(
                        "%s Failed to parse metadata JSON for '%s' v%d: %s",
                        log_identifier,
                        metadata_filename,
                        version,
                        json_err,
                    )
                except Exception as fmt_err:
                    log.warning(
                        "%s Failed to format metadata for '%s' v%d: %s",
                        log_identifier,
                        metadata_filename,
                        version,
                        fmt_err,
                    )
            else:
                log.warning(
                    "%s Companion metadata artifact '%s' v%d not found or empty.",
                    log_identifier,
                    metadata_filename,
                    version,
                )

        except Exception as load_err:
            log.error(
                "%s Error loading companion metadata artifact '%s' v%d: %s",
                log_identifier,
                metadata_filename,
                version,
                load_err,
            )

    if metadata_texts:
        if not isinstance(tool_response, dict):
            log.error(
                "%s Tool response is not a dictionary. Cannot inject metadata. Type: %s",
                log_identifier,
                type(tool_response),
            )
            return None

        combined_metadata_text = "\n\n".join(metadata_texts)
        tool_response[METADATA_RESPONSE_KEY] = combined_metadata_text
        log.info(
            "%s Injected metadata for %d artifact(s) into tool response key '%s'.",
            log_identifier,
            len(metadata_texts),
            METADATA_RESPONSE_KEY,
        )
        return tool_response
    else:
        log.debug(
            "%s No metadata loaded or formatted. Returning original tool response.",
            log_identifier,
        )
        return None


# --- Callback Function for Logging ---
def log_streaming_chunk_callback(
    callback_context: CallbackContext,
    llm_response: LlmResponse,
    host_component: "SamAgentComponent",
) -> Optional[LlmResponse]:
    """
    ADK after_model_callback to log the content of each LLM response chunk
    *after* potential modification by other callbacks (like embed resolution).
    """
    log_identifier = "[Callback:LogChunk]"
    try:
        content_str = "None"
        is_partial = llm_response.partial
        is_final = llm_response.turn_complete
        if llm_response.content and llm_response.content.parts:
            texts = [p.text for p in llm_response.content.parts if p.text]
            content_str = '"' + "".join(texts) + '"' if texts else "[Non-text parts]"
        elif llm_response.error_message:
            content_str = f"[ERROR: {llm_response.error_message}]"

        log.info(
            "%s Received LLM chunk: Partial=%s, Final=%s, Content=%s",
            log_identifier,
            is_partial,
            is_final,
            content_str,
        )
    except Exception as e:
        log.error("%s Error logging LLM chunk: %s", log_identifier, e)

    # This callback only logs, it doesn't modify the response
    return None


# --- Callback Function for Solace LLM Invocation Notification ---
def solace_llm_invocation_callback(
    callback_context: CallbackContext,
    llm_request: LlmRequest,
    host_component: "SamAgentComponent",
) -> Optional[LlmResponse]:
    """
    ADK before_model_callback to send a Solace message when an LLM is invoked,
    using the host_component's process_and_publish_adk_event method.
    """
    log_identifier = "[Callback:SolaceLLMInvocation]"
    log.debug(
        "%s Running Solace LLM invocation notification callback...", log_identifier
    )

    if not host_component:
        log.error(
            "%s Host component instance not provided. Cannot send Solace message.",
            log_identifier,
        )
        return None

    # Reset the processed chunks flag for the new LLM stream
    try:
        from ...common.a2a_protocol import A2A_LLM_STREAM_CHUNKS_PROCESSED_KEY

        callback_context.state[A2A_LLM_STREAM_CHUNKS_PROCESSED_KEY] = False
        log.debug(
            "%s Reset %s to False.", log_identifier, A2A_LLM_STREAM_CHUNKS_PROCESSED_KEY
        )
    except Exception as e_flag_reset:
        log.error(
            "%s Error resetting %s: %s",
            log_identifier,
            A2A_LLM_STREAM_CHUNKS_PROCESSED_KEY,
            e_flag_reset,
        )

    try:
        a2a_context = callback_context.state.get("a2a_context")
        if not a2a_context:
            log.error(
                "%s a2a_context not found in callback_context.state. Cannot send Solace message.",
                log_identifier,
            )
            return None

        agent_name = host_component.get_config("agent_name", "unknown_agent")
        jsonrpc_request_id = a2a_context.get("jsonrpc_request_id")
        logical_task_id = a2a_context.get("logical_task_id")
        peer_status_topic = a2a_context.get("statusTopic")

        status_topic = peer_status_topic or get_gateway_status_topic(
            host_component.get_config("namespace"),
            host_component.get_gateway_id(),
            logical_task_id,
        )

        llm_invocation_metadata = {
            "type": "llm_invocation",
            "data": llm_request.model_dump(exclude_none=True),  # Full LlmRequest
        }
        a2a_message = A2AMessage(
            role="agent",
            parts=[],  # No direct text part for this event
            metadata=llm_invocation_metadata,
        )
        task_status = TaskStatus(
            state=TaskState.WORKING, message=a2a_message, timestamp=datetime.now(timezone.utc)
        )
        status_update_event = TaskStatusUpdateEvent(
            id=logical_task_id,
            status=task_status,
            final=False,
            metadata={
                "agent_name": agent_name
            },  # agent_name is already defined in this scope
        )
        message_payload = JSONRPCResponse(
            id=jsonrpc_request_id, result=status_update_event
        ).model_dump(exclude_none=True)

        host_component._publish_a2a_event(message_payload, status_topic, a2a_context)
        log.info(
            "%s Successfully published LLM invocation status update to Solace topic: %s",
            log_identifier,
            status_topic,
        )

    except Exception as e:
        log.error(
            "%s Error during Solace LLM invocation notification: %s", log_identifier, e
        )

    return None


# --- Callback Function for Solace LLM Response Notification ---
def solace_llm_response_callback(
    callback_context: CallbackContext,
    llm_response: LlmResponse,
    host_component: "SamAgentComponent",
) -> Optional[LlmResponse]:
    """
    ADK after_model_callback to send a Solace message with the LLM's response,
    using the host_component's process_and_publish_adk_event method.
    """
    log_identifier = "[Callback:SolaceLLMResponse]"
    log.info(
        "%s Running Solace LLM response notification callback. Partial: %s, Turn complete: %s",
        log_identifier,
        llm_response.partial,
        llm_response.turn_complete,
    )
    if llm_response.partial:  # Don't send partial responses for this notification
        log.debug("%s Skipping partial response", log_identifier)
        return None

    if not host_component:
        log.error(
            "%s Host component instance not provided. Cannot send Solace message.",
            log_identifier,
        )
        return None

    try:
        a2a_context = callback_context.state.get("a2a_context")
        if not a2a_context:
            log.error(
                "%s a2a_context not found in callback_context.state. Cannot send Solace message.",
                log_identifier,
            )
            # Attempt to reconstruct a minimal context if absolutely necessary, though this is not ideal
            # For now, we will return if full context is missing, as process_and_publish_adk_event relies on it.
            return None

        agent_name = host_component.get_config("agent_name", "unknown_agent")
        jsonrpc_request_id = a2a_context.get("jsonrpc_request_id")
        logical_task_id = a2a_context.get("logical_task_id")
        peer_status_topic = a2a_context.get("statusTopic")

        status_topic = peer_status_topic or get_gateway_status_topic(
            host_component.get_config("namespace"),
            host_component.get_gateway_id(),
            logical_task_id,
        )

        llm_response_metadata = {
            "type": "llm_response",
            "data": llm_response.model_dump(
                exclude_none=True
            ),  # Full LlmResponse object
        }
        a2a_message = A2AMessage(role="agent", parts=[], metadata=llm_response_metadata)
        task_status = TaskStatus(
            state=TaskState.WORKING, message=a2a_message, timestamp=datetime.now(timezone.utc)
        )
        status_update_event = TaskStatusUpdateEvent(
            id=logical_task_id,
            status=task_status,
            final=True,  # Keeping final=True as per the provided file content for this callback
            metadata={
                "agent_name": agent_name
            },  # agent_name is already defined in this scope
        )
        message_payload = JSONRPCResponse(
            id=jsonrpc_request_id, result=status_update_event
        ).model_dump(exclude_none=True)

        host_component._publish_a2a_event(message_payload, status_topic, a2a_context)
        log.info(
            "%s Successfully published LLM response status update (final_chunk=%s) to Solace topic: %s",
            log_identifier,
            llm_response.turn_complete,  # Log still refers to llm_response.turn_complete
            status_topic,
        )

    except Exception as e:
        log.error(
            "%s Error during Solace LLM response notification: %s", log_identifier, e
        )

    return None


# --- Callback Function for Tool Invocation Start Notification ---
def notify_tool_invocation_start_callback(
    tool: BaseTool,
    args: Dict[str, Any],
    tool_context: ToolContext,
    host_component: "SamAgentComponent",
) -> None:  # before_tool_callback does not return a response to modify the flow
    """
    ADK before_tool_callback to send an A2A status message indicating
    that a tool is about to be invoked.
    """
    log_identifier = f"[Callback:NotifyToolInvocationStart:{tool.name}]"
    log.debug(
        "%s Triggered for tool '%s' with args: %s", log_identifier, tool.name, args
    )

    if not host_component:
        log.error(
            "%s Host component instance not provided. Cannot send notification.",
            log_identifier,
        )
        return

    a2a_context = tool_context.state.get("a2a_context")
    if not a2a_context:
        log.error(
            "%s a2a_context not found in tool_context.state. Cannot send notification.",
            log_identifier,
        )
        return

    jsonrpc_request_id = a2a_context.get("jsonrpc_request_id")
    logical_task_id = a2a_context.get("logical_task_id")
    peer_status_topic = a2a_context.get(
        "statusTopic"
    )  # Topic provided by peer delegator
    namespace = host_component.get_config("namespace")
    # Use host_component.get_gateway_id() which returns the agent_name for this context
    gateway_id_for_topic = host_component.get_gateway_id()

    try:
        # Ensure args are JSON serializable
        serializable_args = {}
        for k, v in args.items():
            try:
                json.dumps(v)  # Test serializability
                serializable_args[k] = v
            except TypeError:
                serializable_args[k] = str(v)  # Fallback to string representation

        # No TextPart for this event. Information is in metadata.
        a2a_message_parts = []
        message_metadata = {
            "type": "tool_invocation_start",
            "data": {
                "tool_name": tool.name,
                "tool_args": serializable_args,
                "function_call_id": tool_context.function_call_id,
            },
        }

        a2a_message = A2AMessage(
            role="agent", parts=a2a_message_parts, metadata=message_metadata
        )

        task_status = TaskStatus(
            state=TaskState.WORKING,
            message=a2a_message,  # Message now has empty parts but carries metadata
            timestamp=datetime.now(timezone.utc),
        )

        status_update_event = TaskStatusUpdateEvent(
            id=logical_task_id,
            status=task_status,
            final=False,  # This is an intermediate update
            metadata={"agent_name": host_component.get_config("agent_name")},
        )

        rpc_response = JSONRPCResponse(
            id=jsonrpc_request_id, result=status_update_event
        )
        payload_to_publish = rpc_response.model_dump(exclude_none=True)

    except Exception as e:
        log.exception(
            "%s Error constructing tool_invocation_start status update: %s",
            log_identifier,
            e,
        )
        return

    # Determine Target Topic
    target_topic = peer_status_topic or get_gateway_status_topic(
        namespace, gateway_id_for_topic, logical_task_id
    )

    # Publish Message
    try:
        host_component._publish_a2a_event(
            payload_to_publish, target_topic, a2a_context
        )
        log.info(
            "%s Successfully published tool_invocation_start notification to %s",
            log_identifier,
            target_topic,
        )
    except Exception as e:
        log.exception(
            "%s Failed to publish tool_invocation_start notification: %s",
            log_identifier,
            e,
        )

    return None
