"""
This package contains the business logic layer (services) for the
HTTP SSE Gateway.
"""
