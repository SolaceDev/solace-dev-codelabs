# src/gateway/http_sse/main.py
"""
Defines the FastAPI application instance, mounts routers, and configures middleware.
"""

from fastapi import (
    FastAPI,
    Depends,
    Request as FastAPIRequest,
    HTTPException,
    status,
)
from fastapi.responses import JSONResponse, RedirectResponse
from fastapi.exceptions import RequestValidationError
from fastapi.middleware.cors import CORSMiddleware
from starlette.middleware.sessions import SessionMiddleware
from starlette.staticfiles import StaticFiles
import os
from pathlib import Path
import httpx

# Import SAC logger
from solace_ai_connector.common.log import log

# Import routers (Absolute imports from src/)
from ...gateway.http_sse.routers import (
    agents,
    tasks,
    sse,
    config,
    artifacts,  # Add import for the new artifacts router
    visualization,  # Added: Import the new visualization router
    sessions,  # Added: Import the new sessions router
    people,  # Import the new people router
    users,  # Import the new users router
)

# Import dependency setup function (Absolute import from src/)
from ...gateway.http_sse import dependencies

# Import A2A types for error responses (Absolute import from src/)
from ...common.types import (
    JSONRPCResponse as A2AJSONRPCResponse,
    JSONRPCError,
    InternalError,
    InvalidRequestError,
)

# Import component type hint (Absolute import from src/)
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from gateway.http_sse.component import WebUIBackendComponent

# FastAPI App Instance
app = FastAPI(
    title="A2A Web UI Backend",
    version="0.1.0",
    description="Backend API and SSE server for the A2A Web UI, hosted by Solace AI Connector.",
)

# Middleware and Router Setup Function


def setup_dependencies(component: "WebUIBackendComponent"):
    """
    Sets up the component instance reference and configures middleware and routers
    that depend on the component being available.
    Called from the component's startup sequence.
    """
    log.info("Setting up FastAPI dependencies, middleware, and routers...")
    dependencies.set_component_instance(component)  # Call the function in dependencies.py
    
    webui_app = component.get_app()
    app_config = {}
    if webui_app:
        # Safely get app_config, defaulting to an empty dict if attribute is missing
        app_config = getattr(webui_app, 'app_config', {})
        # If the attribute exists but is None, also default to an empty dict
        if app_config is None:
            log.warning("webui_app.app_config is None, using empty dict.")
            app_config = {}
    else:
        log.warning("Could not get webui_app from component. Using empty app_config.")

    # Extract only the configuration needed by API endpoints
    api_config_dict = {
        "frontend_redirect_url": app_config.get("frontend_redirect_url", "http://localhost:3000"),
    }
    
    dependencies.set_api_config(api_config_dict)
    log.info("API configuration extracted and stored.")


    # The order of middleware is important.
    # 1. CORS Middleware
    # 2. Session Middleware
    allowed_origins = component.get_cors_origins()
    app.add_middleware(
        CORSMiddleware,
        allow_origins=allowed_origins,
        allow_credentials=True,
        allow_methods=["*"],
        allow_headers=["*"],
    )
    log.info("CORSMiddleware added with origins: %s", allowed_origins)

    session_manager = component.get_session_manager()
    app.add_middleware(
        SessionMiddleware, secret_key=session_manager.secret_key
    )
    log.info("SessionMiddleware added.")

    # Mount Routers
    # Mount API routers *BEFORE* static files, using /api/v1 prefix consistently
    api_prefix = "/api/v1"
    app.include_router(config.router, prefix=api_prefix, tags=["Config"])
    app.include_router(agents.router, prefix=api_prefix, tags=["Agents"])
    app.include_router(tasks.router, prefix=f"{api_prefix}/tasks", tags=["Tasks"])
    app.include_router(sse.router, prefix=f"{api_prefix}/sse", tags=["SSE"])
    app.include_router(
        artifacts.router, prefix=f"{api_prefix}/artifacts", tags=["Artifacts"]
    )  # Mount the new artifacts router
    app.include_router(
        visualization.router, prefix=f"{api_prefix}/visualization", tags=["Visualization"]
    ) # Added: Mount the visualization router
    app.include_router(
        sessions.router, prefix=f"{api_prefix}/sessions", tags=["Sessions"]
    )  # Added: Mount the sessions router
    app.include_router(
        people.router, prefix=api_prefix, tags=["People"],
    )  # Mount the new people router
    app.include_router(
        users.router, prefix=f"{api_prefix}/users", tags=["Users"]
    )
    log.info("API routers mounted under prefix: %s", api_prefix)

    # Mount Static Files
    # Serve frontend build files from the new location at the root '/'
    # This should come *AFTER* API routers to avoid intercepting API calls.
    # Assumes a build step outputs to 'dist' and the gateway runs from project root.
    current_dir = os.path.dirname(os.path.abspath(__file__))
    # Construct the root directory
    root_dir = Path(os.path.normpath(os.path.join(current_dir, "..", "..")))
    static_files_dir = Path.joinpath(root_dir, "client", "webui", "frontend", "static")
    if not os.path.isdir(static_files_dir):
        log.warning(
            "Static files directory '%s' not found. Frontend may not be served.",
            static_files_dir,
        )
    else:
        try:
            app.mount(
                "/", StaticFiles(directory=static_files_dir, html=True), name="static"
            )
            log.info("Mounted static files directory '%s' at '/'", static_files_dir)
        except Exception as static_mount_err:
            log.error(
                "Failed to mount static files directory '%s': %s",
                static_files_dir,
                static_mount_err,
            )


# Exception Handlers


@app.exception_handler(HTTPException)
async def http_exception_handler(request: FastAPIRequest, exc: HTTPException):
    """Handles FastAPI's built-in HTTPExceptions and formats them as JSONRPC errors."""
    log.warning(
        "HTTP Exception: Status=%s, Detail=%s, Request: %s %s",
        exc.status_code,
        exc.detail,
        request.method,
        request.url,
    )
    # Attempt to use detail if it's already a JSONRPCError dict, otherwise wrap it
    error_data = None
    error_code = InternalError().code  # Default to internal error
    error_message = str(exc.detail)

    if isinstance(exc.detail, dict):
        # If detail looks like our JSONRPCError structure, use its fields
        if "code" in exc.detail and "message" in exc.detail:
            error_code = exc.detail["code"]
            error_message = exc.detail["message"]
            error_data = exc.detail.get("data")
        else:  # Otherwise, just serialize the dict as data
            error_data = exc.detail

    elif isinstance(exc.detail, str):
        # Map HTTP status codes to approximate JSONRPC error codes if desired
        if exc.status_code == status.HTTP_400_BAD_REQUEST:
            error_code = -32600  # InvalidRequestError code
        elif exc.status_code == status.HTTP_404_NOT_FOUND:
            error_code = -32601  # MethodNotFound or similar resource not found
            error_message = "Resource not found"  # Override generic detail
        # Add other mappings as needed

    error_obj = JSONRPCError(code=error_code, message=error_message, data=error_data)
    response = A2AJSONRPCResponse(error=error_obj)
    return JSONResponse(
        status_code=exc.status_code, content=response.model_dump(exclude_none=True)
    )


@app.exception_handler(RequestValidationError)
async def validation_exception_handler(
    request: FastAPIRequest, exc: RequestValidationError
):
    """Handles Pydantic validation errors (422) and formats them."""
    log.warning(
        "Request Validation Error: %s, Request: %s %s",
        exc.errors(),
        request.method,
        request.url,
    )
    error_obj = InvalidRequestError(
        message="Invalid request parameters", data=exc.errors()
    )
    response = A2AJSONRPCResponse(error=error_obj)
    return JSONResponse(
        status_code=status.HTTP_400_BAD_REQUEST,  # Return 400 for invalid params
        content=response.model_dump(exclude_none=True),
    )


@app.exception_handler(Exception)
async def generic_exception_handler(request: FastAPIRequest, exc: Exception):
    """Handles any other unexpected exceptions."""
    log.exception(
        "Unhandled Exception: %s, Request: %s %s", exc, request.method, request.url
    )  # Log with traceback
    error_obj = InternalError(
        message="An unexpected server error occurred: %s" % type(exc).__name__
    )
    response = A2AJSONRPCResponse(error=error_obj)
    return JSONResponse(
        status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
        content=response.model_dump(exclude_none=True),
    )


# Basic Root Endpoint
# This might be overridden by the static files mount if index.html exists
@app.get("/api/health", tags=["Health"])
async def read_root():
    """Basic health check endpoint."""
    log.debug("Health check endpoint '/api/health' called")
    # Optionally check component status if needed
    # comp = get_sac_component() # Example: Access component via dependency
    return {"status": "A2A Web UI Backend is running"}


log.info(
    "FastAPI application instance created (endpoints/middleware/static files setup deferred until component startup)."
)
