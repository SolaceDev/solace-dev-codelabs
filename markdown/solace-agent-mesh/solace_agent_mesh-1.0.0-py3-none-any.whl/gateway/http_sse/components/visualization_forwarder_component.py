"""
SAC Component to forward messages from an internal BrokerInput
to the WebUIBackendComponent's internal queue for visualization.
"""

import queue
from typing import Any, Dict

from solace_ai_connector.components.component_base import ComponentBase
from solace_ai_connector.common.message import Message as SolaceMessage
from solace_ai_connector.common.log import log

# Define the component information dictionary
info = {
    "class_name": "VisualizationForwarderComponent",
    "description": (
        "Forwards A2A messages from an internal BrokerInput to the main "
        "WebUIBackendComponent's internal queue for visualization."
    ),
    "config_parameters": [
        {
            "name": "target_queue_ref",
            "required": True,
            "type": "queue.Queue", # Type for documentation; passed programmatically
            "description": "A direct reference to the target queue.Queue instance in WebUIBackendComponent.",
        }
    ],
    "input_schema": {
        "type": "object",
        "description": "Output from a BrokerInput component.",
        "properties": {
            "payload": {"type": "any", "description": "The message payload."},
            "topic": {"type": "string", "description": "The message topic."},
            "user_properties": {
                "type": "object",
                "description": "User properties of the message.",
            },
            # BrokerInput also includes _original_message, but it's not part of 'data' to invoke.
            # The 'message' argument to invoke IS the _original_message from BrokerInput.
        },
        "required": ["payload", "topic"],
    },
    "output_schema": None, # This component does not output to another SAC component
}


class VisualizationForwarderComponent(ComponentBase):
    """
    A simple SAC component that takes messages from its input (typically
    from a BrokerInput) and puts them onto a target Python queue.Queue
    instance provided in its configuration.
    """

    def __init__(self, **kwargs: Any):
        super().__init__(info, **kwargs)
        self.target_queue: queue.Queue = self.get_config("target_queue_ref")
        if not isinstance(self.target_queue, queue.Queue):
            log.error(
                "%s Configuration 'target_queue_ref' is not a valid queue.Queue instance. Type: %s",
                self.log_identifier,
                type(self.target_queue)
            )
            # This is a critical configuration error.
            raise ValueError(
                f"{self.log_identifier} 'target_queue_ref' must be a queue.Queue instance."
            )
        log.info("%s VisualizationForwarderComponent initialized.", self.log_identifier)

    def invoke(self, message: SolaceMessage, data: Dict[str, Any]) -> None:
        """
        Processes the incoming message and forwards it.

        Args:
            message: The SolaceMessage object from BrokerInput (this is the original message).
            data: The data extracted by BrokerInput's output_schema (payload, topic, user_properties).
        """
        log_id_prefix = f"{self.log_identifier}[Invoke]"
        try:
            # Construct the dictionary to put on the target queue
            # 'message' is the SolaceMessage object itself, which BrokerInput provides.
            # 'data' is the dictionary {payload, topic, user_properties} from BrokerInput's output.
            forward_data = {
                "topic": data.get("topic"),
                "payload": data.get("payload"), # This is already decoded by BrokerInput
                "user_properties": data.get("user_properties"),
                "_original_broker_message": message, # Pass the SolaceMessage for ACK/NACK
            }
            log.debug(
                "%s Forwarding message for topic: %s",
                log_id_prefix,
                forward_data["topic"],
            )
            self.target_queue.put(forward_data)

            # Acknowledge the message to the preceding BrokerInput
            message.call_acknowledgements()
            log.debug("%s Message acknowledged to BrokerInput.", log_id_prefix)

        except Exception as e:
            log.exception(
                "%s Error in VisualizationForwarderComponent invoke: %s",
                log_id_prefix,
                e,
            )
            # NACK the message if an error occurs during forwarding
            if message:
                message.call_negative_acknowledgements()
            # Re-raise the exception to let SAC handle component error
            raise
        return None
