# src/gateway/http_sse/app.py
"""
Custom Solace AI Connector App class for the Web UI Backend.
Defines configuration schema and programmatically creates the WebUIBackendComponent.
"""

from typing import Any, Dict, List
from solace_ai_connector.common.utils import deep_merge  # For schema merging
from solace_ai_connector.common.log import log

# Import the component class (Absolute import from src/)
from ...gateway.http_sse.component import WebUIBackendComponent

# Import GDK base classes (Absolute import from src/)
from ...gateway.base.app import BaseGatewayApp # No longer need BASE_GATEWAY_APP_SCHEMA here
from ...gateway.base.component import BaseGatewayComponent  # For type hint


# Module-level info dictionary required by SAC when using app_module
info = {
    "class_name": "WebUIBackendApp",
    "description": "Custom App class for the A2A Web UI Backend with automatic subscription generation.",
}


class WebUIBackendApp(BaseGatewayApp):
    """
    Custom App class for the A2A Web UI Backend.
    - Extends BaseGatewayApp for common gateway functionalities.
    - Defines WebUI-specific configuration parameters.
    """

    # Define WebUI-specific parameters separately
    # This list will be automatically merged with BaseGatewayApp's schema
    # by BaseGatewayApp.__init_subclass__
    SPECIFIC_APP_SCHEMA_PARAMS: List[Dict[str, Any]] = [
        # Required
        {
            "name": "session_secret_key",
            "required": True,
            "type": "string",
            "description": "Secret key for signing web user sessions.",
        },
        # Optional with Defaults
        {
            "name": "fastapi_host",
            "required": False,
            "type": "string",
            "default": "127.0.0.1",
            "description": "Host address for the embedded FastAPI server.",
        },
        {
            "name": "fastapi_port",
            "required": False,
            "type": "integer",
            "default": 8000,
            "description": "Port for the embedded FastAPI server.",
        },
        {
            "name": "cors_allowed_origins",
            "required": False,
            "type": "list",
            "default": ["*"],
            "description": "List of allowed origins for CORS requests.",
        },
        {
            "name": "resolve_artifact_uris_in_gateway",
            "required": False,
            "type": "boolean",
            "default": True,
            "description": "If true, the gateway will resolve artifact:// URIs found in A2A messages and embed the content as bytes before sending to the UI. If false, URIs are passed through.",
        },
        {
            "name": "system_purpose",
            "required": False,
            "type": "string",
            "default": "",
            "description": "Detailed description of the system's overall purpose, to be optionally used by agents.",
        },
        {
            "name": "response_format",
            "required": False,
            "type": "string",
            "default": "",
            "description": "General guidelines on how agent responses should be structured, to be optionally used by agents.",
        },
        # Frontend Config Passthrough
        {
            "name": "frontend_welcome_message",
            "required": False,
            "type": "string",
            "default": "Hi! How can I help?",
            "description": "Initial welcome message displayed in the chat.",
        },
        {
            "name": "frontend_bot_name",
            "required": False,
            "type": "string",
            "default": "A2A Agent",
            "description": "Name displayed for the bot/agent in the UI.",
        },
        {
            "name": "frontend_collect_feedback",
            "required": False,
            "type": "boolean",
            "default": False,
            "description": "Enable/disable the feedback buttons in the UI.",
        },
        {
            "name": "frontend_auth_login_url",
            "required": False,
            "type": "string",
            "default": "",
            "description": "URL for the external login page (if auth is enabled).",
        },
        {
            "name": "frontend_use_authorization",
            "required": False,
            "type": "boolean",
            "default": False,
            "description": "Tell frontend whether backend expects authorization.",
        },
        {
            "name": "frontend_redirect_url",
            "required": False,
            "type": "string",
            "default": "",
            "description": "Redirect URL for OAuth flows (if auth is enabled).",
        },
        {
            "name": "external_auth_callback_uri",
            "required": False,
            "type": "string",
            "default": "",
            "description": "Redirect URI for the OIDC application.",
        },
        {
            "name": "external_auth_service_url",
            "required": False,
            "type": "string",
            "default": "http://localhost:8080",
            "description": "External authorization service URL for login initiation.",
        },
        {
            "name": "external_auth_provider",
            "required": False,
            "type": "string",
            "default": "",
            "description": "The external authentication provider.",
        },
    ]

    # The 'app_schema' attribute is now automatically created by BaseGatewayApp.__init_subclass__
    # by merging BASE_GATEWAY_APP_SCHEMA with SPECIFIC_APP_SCHEMA_PARAMS.
    # No need to define app_schema here explicitly.

    def __init__(self, app_info: Dict[str, Any], **kwargs):
        """
        Initializes the WebUIBackendApp.
        Most setup is handled by BaseGatewayApp.
        """
        log.debug(
            "%s Initializing WebUIBackendApp...",
            app_info.get("name", "WebUIBackendApp"),
        )
        super().__init__(app_info=app_info, **kwargs)
        log.debug("%s WebUIBackendApp initialization complete.", self.name)

    def _get_gateway_component_class(self) -> type[BaseGatewayComponent]:
        return WebUIBackendComponent
