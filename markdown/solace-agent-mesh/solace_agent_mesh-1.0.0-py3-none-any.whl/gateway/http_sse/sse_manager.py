# src/gateway/http_sse/sse_manager.py
"""
Manages Server-Sent Event (SSE) connections for streaming task updates.
"""

import asyncio
import threading
from typing import Dict, List, Any
import json

# Import SAC logger
from solace_ai_connector.common.log import log


class SSEManager:
    """
    Manages active SSE connections and distributes events based on task ID.
    Uses asyncio Queues for buffering events per connection.
    """

    def __init__(self):
        # Dictionary mapping task_id to a list of asyncio.Queues
        # Each queue represents an active SSE connection listening for that task.
        self._connections: Dict[str, List[asyncio.Queue]] = {}
        self._locks: Dict[asyncio.AbstractEventLoop, asyncio.Lock] = {}
        self._locks_lock = threading.Lock()
        self.log_identifier = "[SSEManager]"

    def _get_lock(self) -> asyncio.Lock:
        """Get or create a lock for the current event loop."""
        try:
            current_loop = asyncio.get_running_loop()
        except RuntimeError:
            # This might happen if called from a non-async context, which is an error.
            log.error(
                "%s _get_lock must be called from within an async context.",
                self.log_identifier,
            )
            raise RuntimeError(
                "SSEManager methods must be called from within an async context"
            )

        with self._locks_lock:
            if current_loop not in self._locks:
                self._locks[current_loop] = asyncio.Lock()
                log.debug(
                    "%s Created new lock for event loop %s",
                    self.log_identifier,
                    id(current_loop),
                )
            return self._locks[current_loop]

    async def create_sse_connection(self, task_id: str) -> asyncio.Queue:
        """
        Creates a new queue for an SSE connection subscribing to a task.

        Args:
            task_id: The ID of the task the connection is interested in.

        Returns:
            An asyncio.Queue that the SSE endpoint can consume from.
        """
        lock = self._get_lock()
        async with lock:
            if task_id not in self._connections:
                self._connections[task_id] = []

            # Create a new queue for this specific connection
            # Limit buffer size to prevent excessive memory usage.
            connection_queue = asyncio.Queue(maxsize=100)
            self._connections[task_id].append(connection_queue)
            log.info(
                "%s Created SSE connection queue for Task ID: %s. Total queues for task: %d",
                self.log_identifier,
                task_id,
                len(self._connections[task_id]),
            )
            return connection_queue

    async def remove_sse_connection(
        self, task_id: str, connection_queue: asyncio.Queue
    ):
        """
        Removes a specific SSE connection queue for a task.

        Args:
            task_id: The ID of the task.
            connection_queue: The specific queue instance to remove.
        """
        lock = self._get_lock()
        async with lock:
            if task_id in self._connections:
                try:
                    self._connections[task_id].remove(connection_queue)
                    log.info(
                        "%s Removed SSE connection queue for Task ID: %s. Remaining queues: %d",
                        self.log_identifier,
                        task_id,
                        len(self._connections[task_id]),
                    )
                    # If no more connections for this task, remove the task entry
                    if not self._connections[task_id]:
                        del self._connections[task_id]
                        log.info(
                            "%s Removed Task ID entry: %s as no connections remain.",
                            self.log_identifier,
                            task_id,
                        )
                except ValueError:
                    # This can happen if the queue was already removed (e.g., during close_all)
                    log.debug(
                        "%s Attempted to remove an already removed queue for Task ID: %s.",
                        self.log_identifier,
                        task_id,
                    )
            else:
                log.warning(
                    "%s Attempted to remove queue for non-existent Task ID: %s.",
                    self.log_identifier,
                    task_id,
                )

    async def send_event(
        self, task_id: str, event_data: Dict[str, Any], event_type: str = "message"
    ):
        """
        Sends an event (as a dictionary) to all active SSE connections for a specific task.
        The event_data dictionary will be JSON serialized for the SSE 'data' field.

        Args:
            task_id: The ID of the task the event belongs to.
            event_data: The dictionary representing the A2A event (e.g., TaskStatusUpdateEvent).
            event_type: The type of the SSE event (default: "message").
        """
        lock = self._get_lock()
        async with lock:
            if task_id not in self._connections:
                log.debug(
                    "%s No active SSE connections for Task ID: %s. Event not sent.",
                    self.log_identifier,
                    task_id,
                )
                return

            queues_to_remove = []
            try:
                # Serialize the data payload ONCE
                serialized_data = json.dumps(event_data)
            except Exception as json_err:
                log.error(
                    "%s Failed to JSON serialize event data for Task ID %s: %s",
                    self.log_identifier,
                    task_id,
                    json_err,
                )
                return  # Cannot send unserializable data

            # Prepare the SSE payload structure
            sse_payload = {"event": event_type, "data": serialized_data}
            log.debug(
                "%s Prepared SSE payload for Task ID %s: %s",
                self.log_identifier,
                task_id,
                sse_payload,
            )

            # Iterate through a copy of the list to allow safe removal
            for connection_queue in list(self._connections.get(task_id, [])):
                try:
                    # Put the pre-formatted SSE payload dictionary onto the queue
                    await asyncio.wait_for(
                        connection_queue.put(sse_payload), timeout=0.1
                    )  # Small timeout
                    log.debug(
                        "%s Queued event for Task ID: %s to one connection.",
                        self.log_identifier,
                        task_id,
                    )
                except asyncio.QueueFull:
                    log.warning(
                        "%s SSE connection queue full for Task ID: %s. Event dropped for one connection.",
                        self.log_identifier,
                        task_id,
                    )
                    # Mark this queue for removal if it's consistently full
                    queues_to_remove.append(connection_queue)
                except asyncio.TimeoutError:
                    log.warning(
                        "%s Timeout putting event onto SSE queue for Task ID: %s. Event dropped for one connection.",
                        self.log_identifier,
                        task_id,
                    )
                    queues_to_remove.append(connection_queue)
                except Exception as e:
                    log.error(
                        "%s Error putting event onto queue for Task ID %s: %s",
                        self.log_identifier,
                        task_id,
                        e,
                    )
                    # Mark potentially broken queues for removal
                    queues_to_remove.append(connection_queue)

            # Clean up queues marked for removal (outside the iteration)
            if queues_to_remove and task_id in self._connections:
                current_queues = self._connections[task_id]
                for q in queues_to_remove:
                    try:
                        current_queues.remove(q)
                        log.warning(
                            "%s Removed potentially broken/full SSE queue for Task ID: %s",
                            self.log_identifier,
                            task_id,
                        )
                    except ValueError:
                        pass  # Already removed

                if not current_queues:  # Check if list is now empty
                    del self._connections[task_id]
                    log.info(
                        "%s Removed Task ID entry: %s after cleaning queues.",
                        self.log_identifier,
                        task_id,
                    )

    async def close_connection(self, task_id: str, connection_queue: asyncio.Queue):
        """
        Signals a specific SSE connection queue to close by putting None.
        Also removes the queue from the manager.
        """
        log.info(
            "%s Closing specific SSE connection queue for Task ID: %s",
            self.log_identifier,
            task_id,
        )
        try:
            # Put None onto the queue to signal the consumer (SSE endpoint) to stop
            await asyncio.wait_for(connection_queue.put(None), timeout=0.1)
        except asyncio.QueueFull:
            log.warning(
                "%s Could not put None (close signal) on full queue for Task ID: %s. Connection might not close cleanly.",
                self.log_identifier,
                task_id,
            )
        except asyncio.TimeoutError:
            log.warning(
                "%s Timeout putting None (close signal) on queue for Task ID: %s.",
                self.log_identifier,
                task_id,
            )
        except Exception as e:
            log.error(
                "%s Error putting None (close signal) on queue for Task ID %s: %s",
                self.log_identifier,
                task_id,
                e,
            )
        finally:
            # Always try to remove the queue from management
            await self.remove_sse_connection(task_id, connection_queue)

    async def close_all_for_task(self, task_id: str):
        """
        Closes all SSE connections associated with a specific task.
        """
        lock = self._get_lock()
        async with lock:
            if task_id in self._connections:
                queues_to_close = self._connections.pop(
                    task_id
                )  # Remove entry and get queues
                log.info(
                    "%s Closing %d SSE connections for Task ID: %s",
                    self.log_identifier,
                    len(queues_to_close),
                    task_id,
                )
                for q in queues_to_close:
                    try:
                        # Signal consumer to stop
                        await asyncio.wait_for(q.put(None), timeout=0.1)
                    except asyncio.QueueFull:
                        log.warning(
                            "%s Could not put None (close signal) on full queue during close_all for Task ID: %s.",
                            self.log_identifier,
                            task_id,
                        )
                    except asyncio.TimeoutError:
                        log.warning(
                            "%s Timeout putting None (close signal) on queue during close_all for Task ID: %s.",
                            self.log_identifier,
                            task_id,
                        )
                    except Exception as e:
                        log.error(
                            "%s Error putting None (close signal) on queue during close_all for Task ID %s: %s",
                            self.log_identifier,
                            task_id,
                            e,
                        )
                log.info(
                    "%s Removed Task ID entry: %s and signaled queues to close.",
                    self.log_identifier,
                    task_id,
                )
            else:
                log.debug(
                    "%s No connections found to close for Task ID: %s",
                    self.log_identifier,
                    task_id,
                )

    def cleanup_old_locks(self):
        """Remove locks for closed event loops to prevent memory leaks."""
        with self._locks_lock:
            closed_loops = [
                loop for loop in self._locks if loop.is_closed()
            ]
            for loop in closed_loops:
                del self._locks[loop]
                log.debug(
                    "%s Cleaned up lock for closed event loop %s",
                    self.log_identifier,
                    id(loop),
                )

    async def close_all(self):
        """Closes all active SSE connections managed by this instance."""
        self.cleanup_old_locks()
        lock = self._get_lock()
        async with lock:
            log.info("%s Closing all active SSE connections...", self.log_identifier)
            all_task_ids = list(self._connections.keys())
            closed_count = 0
            for task_id in all_task_ids:
                if (
                    task_id in self._connections
                ):  # Check again in case removed concurrently
                    queues = self._connections.pop(task_id)
                    closed_count += len(queues)
                    for q in queues:
                        try:
                            await asyncio.wait_for(q.put(None), timeout=0.1)
                        except Exception:
                            pass  # Ignore errors during mass shutdown
            log.info(
                "%s Closed %d connections for tasks: %s",
                self.log_identifier,
                closed_count,
                all_task_ids,
            )
            self._connections.clear()
