# src/gateway/http_sse/routers/agents.py
"""
API Router for agent discovery.
"""

from fastapi import APIRouter, Depends, HTTPException, status
from typing import List

# Import SAC logger
from solace_ai_connector.common.log import log

# Import shared registry and types (Absolute imports from src/)
from ....common.agent_registry import AgentRegistry  # Use new path
from ....common.types import AgentCard  # Use new path

# Import dependency injectors from dependencies.py (Absolute import from src/)
from ....gateway.http_sse.dependencies import get_agent_registry  # Use new path

router = APIRouter()


@router.get("/agents", response_model=List[AgentCard])
async def get_discovered_agents(
    agent_registry: AgentRegistry = Depends(get_agent_registry),  # Use updated import
):
    """
    Retrieves a list of all currently discovered A2A agents.
    """
    log_prefix = "[GET /api/v1/agents] "  # Corrected path in log
    log.info("%sRequest received.", log_prefix)
    try:
        # Assuming AgentRegistry has a method like get_all_agent_cards() or we adapt get_agent() usage
        agent_names = agent_registry.get_agent_names()
        agents = [
            agent_registry.get_agent(name)
            for name in agent_names
            if agent_registry.get_agent(name)
        ]

        log.info("%sReturning %d discovered agents.", log_prefix, len(agents))
        return agents
    except Exception as e:
        log.exception("%sError retrieving discovered agents: %s", log_prefix, e)
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Internal server error retrieving agent list.",
        )


# Example of getting a specific agent (optional)
# @router.get("/agents/{agent_name}", response_model=AgentCard)
# async def get_agent_details(
#     agent_name: str,
#     agent_registry: AgentRegistry = Depends(get_agent_registry) # Use updated import
# ):
#     """
#     Retrieves details for a specific agent by name.
#     """
#     log.info("API Request: GET /api/agents/%s", agent_name)
#     agent = agent_registry.get_agent(agent_name)
#     if agent is None:
#         log.warning("Agent '%s' not found.", agent_name)
#         raise HTTPException(status_code=404, detail=f"Agent '{agent_name}' not found")
#     return agent
