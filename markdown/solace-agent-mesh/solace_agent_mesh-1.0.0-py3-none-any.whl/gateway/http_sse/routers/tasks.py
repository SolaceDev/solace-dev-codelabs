# src/gateway/http_sse/routers/tasks.py
"""
API Router for submitting and managing tasks to agents.
"""

from fastapi import (
    APIRouter,
    Depends,
    HTTPException,
    Request as FastAPIRequest,
    status,
    Form,
    File,
    UploadFile,
)
from pydantic import BaseModel, Field
from typing import List, Optional

# Import SAC logger
from solace_ai_connector.common.log import log

# Import services and managers (Absolute imports from src/)
from ....gateway.http_sse.session_manager import SessionManager
from ....gateway.http_sse.services.task_service import TaskService # Added import

# Import A2A types for response (Absolute import from src/)
from ....common.types import (
    JSONRPCResponse,
    InternalError,
    InvalidRequestError,
    TaskIdParams,
)

# Import dependency injectors from dependencies.py (Absolute import from src/)
from ....gateway.http_sse.dependencies import (
    get_session_manager,
    get_sac_component, # Added to get component instance
    get_task_service, # Added import
)
from ....gateway.http_sse.routers.users import get_current_user

# Import component type hint
from typing import TYPE_CHECKING
if TYPE_CHECKING:
    from ....gateway.http_sse.component import WebUIBackendComponent

router = APIRouter()

# Request Body Models (Keep CancelTaskApiPayload)


class CancelTaskApiPayload(BaseModel):
    """Request body for the task cancellation endpoint."""

    agent_name: str = Field(
        ..., description="The name of the agent currently handling the task."
    )
    task_id: str = Field(..., description="The ID of the task to cancel.")


# Endpoints


@router.post("/send", response_model=JSONRPCResponse)
async def send_task_to_agent(
    request: FastAPIRequest,
    # Use Form fields instead of Pydantic model in body
    agent_name: str = Form(...),
    message: str = Form(...),
    files: List[UploadFile] = File([]),
    session_manager: SessionManager = Depends(get_session_manager),
    component: "WebUIBackendComponent" = Depends(get_sac_component),
):
    """
    Submits a non-streaming task request to the specified agent.
    Accepts multipart/form-data.
    """
    log_prefix = "[POST /api/v1/tasks/send] "
    log.info("%sReceived request for agent: %s", log_prefix, agent_name)

    try:
        # Create a default user identity for community edition
        user_identity = {"id": "default_user", "name": "Default User"}

        # Get client_id and ensure a session_id exists for this web session
        client_id = session_manager.get_a2a_client_id(request)
        # Use ensure_a2a_session to create one if it doesn't exist yet
        session_id = session_manager.ensure_a2a_session(request)

        log.info(
            "%sUsing ClientID: %s, SessionID: %s", log_prefix, client_id, session_id
        )

        # 1. Construct external_event_data for _translate_external_input
        external_event_data = {
            "agent_name": agent_name,
            "message": message,
            "files": files,
            "client_id": client_id,
            "a2a_session_id": session_id,
        }

        # 2. Call component's translation method
        target_agent, a2a_parts, external_req_ctx = await component._translate_external_input(external_event_data)

        # 3. Call component's submission method (from BaseGatewayComponent)
        # Task 3.3: Pass user_identity to submit_a2a_task
        task_id = await component.submit_a2a_task(
            target_agent_name=target_agent,
            a2a_parts=a2a_parts,
            external_request_context=external_req_ctx,
            user_identity=user_identity,
            is_streaming=False
        )

        log.info("%sTask submitted successfully. TaskID: %s", log_prefix, task_id)

        # Return success response with task ID
        return JSONRPCResponse(result={"taskId": task_id})

    except InvalidRequestError as e:
        log.warning("%sInvalid request: %s", log_prefix, e.message, exc_info=True)
        # Return the specific A2A error if raised by the service
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=e.model_dump(exclude_none=True),
        )
    except PermissionError as pe: # Catch PermissionError from submit_a2a_task
        log.warning("%sPermission denied: %s", log_prefix, str(pe))
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail=str(pe),
        )
    except InternalError as e:
        log.error(
            "%sInternal error submitting task: %s", log_prefix, e.message, exc_info=True
        )
        # Return the specific A2A error if raised by the service
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=e.model_dump(exclude_none=True),
        )
    except Exception as e:
        log.exception("%sUnexpected error submitting task: %s", log_prefix, e)
        # Wrap unexpected errors in InternalError
        error_resp = InternalError(message="Unexpected server error: %s" % e)
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=error_resp.model_dump(exclude_none=True),
        )


@router.post("/subscribe", response_model=JSONRPCResponse)
async def subscribe_task_from_agent(
    request: FastAPIRequest,
    # Use Form fields instead of Pydantic model in body
    agent_name: str = Form(...),
    message: str = Form(...),
    files: List[UploadFile] = File([]),
    session_manager: SessionManager = Depends(get_session_manager),
    component: "WebUIBackendComponent" = Depends(get_sac_component),
    user: dict = Depends(get_current_user),
):
    """
    Submits a streaming task request (`tasks/sendSubscribe`) to the specified agent.
    Accepts multipart/form-data.
    The client should subsequently connect to the SSE endpoint using the returned taskId.
    """
    log_prefix = "[POST /api/v1/tasks/subscribe] "
    log.info("%sReceived streaming request for agent: %s", log_prefix, agent_name)

    try:
        # Create a default user identity for community edition
        user_identity = {"id": "default_user", "name": "Default User"}

        # Get client_id and ensure a session_id exists for this web session
        client_id = session_manager.get_a2a_client_id(request)
        session_id = session_manager.ensure_a2a_session(request)

        log.info(
            "%sUsing ClientID: %s, SessionID: %s", log_prefix, client_id, session_id
        )

        # 1. Construct external_event_data for _translate_external_input
        external_event_data = {
            "agent_name": agent_name,
            "message": message,
            "files": files,
            "client_id": client_id,
            "a2a_session_id": session_id,
        }

        # 2. Call component's translation method
        target_agent, a2a_parts, external_req_ctx = await component._translate_external_input(external_event_data)

        # 3. Call component's submission method (from BaseGatewayComponent)
        # Task 3.3: Pass user_identity to submit_a2a_task
        task_id = await component.submit_a2a_task(
            target_agent_name=target_agent,
            a2a_parts=a2a_parts,
            external_request_context=external_req_ctx,
            user_identity=user_identity,
            is_streaming=True
        )

        log.info(
            "%sStreaming task submitted successfully. TaskID: %s", log_prefix, task_id
        )

        # Return success response with task ID
        return JSONRPCResponse(result={"taskId": task_id})

    except InvalidRequestError as e:
        log.warning("%sInvalid request: %s", log_prefix, e.message, exc_info=True)
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=e.model_dump(exclude_none=True),
        )
    except PermissionError as pe: # Catch PermissionError from submit_a2a_task
        log.warning("%sPermission denied: %s", log_prefix, str(pe))
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail=str(pe),
        )
    except InternalError as e:
        log.error(
            "%sInternal error submitting streaming task: %s",
            log_prefix,
            e.message,
            exc_info=True,
        )
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=e.model_dump(exclude_none=True),
        )
    except Exception as e:
        log.exception("%sUnexpected error submitting streaming task: %s", log_prefix, e)
        error_resp = InternalError(message="Unexpected server error: %s" % e)
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=error_resp.model_dump(exclude_none=True),
        )


@router.post("/cancel", status_code=status.HTTP_202_ACCEPTED)
async def cancel_agent_task(
    request: FastAPIRequest,
    payload: CancelTaskApiPayload,
    session_manager: SessionManager = Depends(get_session_manager),
    task_service: TaskService = Depends(get_task_service), # Keep TaskService for cancel
):
    """
    Sends a cancellation request for a specific task to the specified agent.
    Returns 202 Accepted, as cancellation is asynchronous.
    """
    log_prefix = "[POST /api/v1/tasks/cancel][Task:%s] " % payload.task_id
    log.info(
        "%sReceived cancellation request for agent: %s", log_prefix, payload.agent_name
    )

    try:
        # Get client_id (needed for user properties)
        client_id = session_manager.get_a2a_client_id(request)
        # user_id could also be retrieved if needed

        log.info("%sUsing ClientID: %s", log_prefix, client_id)

        # Construct A2A cancel request using CoreA2AService via the component
        # BaseGatewayComponent does not have a cancel_a2a_task method yet.
        # For now, let's assume CoreA2AService is used directly or via a helper.
        # This part might need a new method in BaseGatewayComponent or keep using TaskService for cancel.
        # For GDK consistency, let's assume a method on the component.
        # If not present, this will require adding it to BaseGatewayComponent or keeping TaskService for cancel.
        # For this task, we'll keep TaskService for cancel to limit scope of this change.
        # task_service: TaskService = Depends(get_task_service) # Already injected
        await task_service.cancel_task(payload.agent_name, payload.task_id, client_id, client_id)

        log.info("%sCancellation request published successfully.", log_prefix)

        # Return 202 Accepted - no response body needed
        return {"message": "Cancellation request sent"}

    except InvalidRequestError as e:
        log.warning(
            "%sInvalid cancellation request: %s", log_prefix, e.message, exc_info=True
        )
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=e.model_dump(exclude_none=True),
        )
    except InternalError as e:
        log.error(
            "%sInternal error sending cancellation: %s",
            log_prefix,
            e.message,
            exc_info=True,
        )
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=e.model_dump(exclude_none=True),
        )
    except Exception as e:
        log.exception("%sUnexpected error sending cancellation: %s", log_prefix, e)
        error_resp = InternalError(message="Unexpected server error: %s" % e)
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=error_resp.model_dump(exclude_none=True),
        )
