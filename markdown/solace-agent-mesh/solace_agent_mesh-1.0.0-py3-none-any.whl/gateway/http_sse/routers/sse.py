# src/gateway/http_sse/routers/sse.py
"""
API Router for Server-Sent Events (SSE) subscriptions.
"""

import asyncio
import json
from fastapi import APIRouter, Depends, Request as FastAPIRequest, HTTPException, status

# Import SAC logger
from solace_ai_connector.common.log import log

# Use sse-starlette for SSE responses
from sse_starlette.sse import EventSourceResponse

# Import managers and dependency injectors (Absolute imports from src/)
from ....gateway.http_sse.sse_manager import SSEManager
from ....gateway.http_sse.dependencies import get_sse_manager

router = APIRouter()


@router.get("/subscribe/{task_id}")
async def subscribe_to_task_events(
    task_id: str,
    request: FastAPIRequest,  # Inject request for disconnection detection
    sse_manager: SSEManager = Depends(get_sse_manager),
):
    """
    Establishes an SSE connection to receive real-time updates for a specific task.
    """
    log_prefix = "[GET /api/v1/sse/subscribe/%s] " % task_id
    log.info("%sClient requesting SSE subscription.", log_prefix)

    connection_queue: asyncio.Queue = None
    try:
        # Create a queue for this specific client connection
        connection_queue = await sse_manager.create_sse_connection(task_id)
        log.info("%sSSE connection queue created.", log_prefix)

        async def event_generator():
            nonlocal connection_queue  # Ensure we use the queue created outside
            log.debug("%sSSE event generator started.", log_prefix)
            try:
                # Send initial ping
                yield {"comment": "SSE connection established"}
                log.debug("%sSent initial SSE comment.", log_prefix)

                loop_count = 0
                while True:
                    loop_count += 1
                    log.debug("%sEvent generator loop iteration: %d", log_prefix, loop_count)

                    # Check if client disconnected
                    disconnected = await request.is_disconnected()
                    log.debug("%sRequest disconnected status: %s", log_prefix, disconnected)
                    if disconnected:
                        log.info("%sClient disconnected. Breaking loop.", log_prefix)
                        break

                    try:
                        log.debug("%sWaiting for event from queue...", log_prefix)
                        # Wait for an event from the queue
                        event_payload = await asyncio.wait_for(
                            connection_queue.get(), timeout=120
                        )  # Timeout to check disconnect
                        log.debug("%sReceived from queue: %s", log_prefix, event_payload is not None)

                        if event_payload is None:
                            log.info(
                                "%sReceived None sentinel. Closing connection. Breaking loop.",
                                log_prefix,
                            )
                            break  # Signal to close connection

                        # event_payload is expected to be a dict like {"event": "type", "data": "json_string"}
                        # The SSE connection should remain open for all event types, including
                        # status_update with final:true. It will only close if event_payload is None
                        # (sent by SSEManager.close_all_for_task/close_connection) or if the client disconnects.
                        log.debug("%sYielding event_payload: %s", log_prefix, event_payload)
                        yield event_payload
                        connection_queue.task_done()
                        log.debug(
                            "%sSent event: %s", log_prefix, event_payload.get("event")
                        )

                    except asyncio.TimeoutError:
                        # No event received, just loop again to check disconnect
                        log.debug(
                            "%sSSE queue wait timed out (iteration %d), checking disconnect status.",
                            log_prefix,
                            loop_count,
                        )
                        # Send a keep-alive comment (optional)
                        # yield {"comment": "keep-alive"}
                        continue
                    except asyncio.CancelledError:
                        log.info("%sSSE event generator cancelled. Breaking loop.", log_prefix)
                        break
                    except Exception as q_err:
                        log.error(
                            "%sError getting event from queue: %s. Breaking loop.",
                            log_prefix,
                            q_err,
                            exc_info=True,
                        )
                        # Optionally send an error event to the client
                        yield {
                            "event": "error",
                            "data": json.dumps({"error": "Internal queue error"}),
                        }
                        break  # Stop generation on queue error

            except asyncio.CancelledError:
                log.info("%sSSE event generator explicitly cancelled. Breaking loop.", log_prefix)
            except Exception as gen_err:
                log.error(
                    "%sError in SSE event generator: %s",
                    log_prefix,
                    gen_err,
                    exc_info=True,
                )
            finally:
                log.info("%sSSE event generator finished.", log_prefix)
                # Clean up the queue connection in SSEManager if it still exists
                if connection_queue:
                    await sse_manager.remove_sse_connection(task_id, connection_queue)
                    log.info("%sRemoved SSE connection queue from manager.", log_prefix)

        # Return the EventSourceResponse with the generator
        return EventSourceResponse(event_generator())

    except Exception as e:
        log.exception("%sError establishing SSE connection: %s", log_prefix, e)
        # Clean up queue if created before error
        if connection_queue:
            await sse_manager.remove_sse_connection(task_id, connection_queue)
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to establish SSE connection: %s" % e,
        )
