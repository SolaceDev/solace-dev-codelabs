"""
This package contains the FastAPI router modules for the HTTP SSE Gateway.
Each file defines a set of related API endpoints.
"""
