# src/gateway/base/__init__.py
"""Base classes and utilities for the Gateway Development Kit (GDK)."""
