import click
import os
import sys

SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
sys.path.append(os.path.dirname(SCRIPT_DIR))

from cli import __version__
from cli.commands.init_cmd import init
from cli.commands.run_cmd import run
from cli.commands.add_cmd import add
from cli.commands.plugin_cmd import plugin

@click.group()
@click.version_option(__version__, "-v", "--version", help="Show the CLI version and exit.")
def cli():
    """Solace CLI Application"""
    pass

cli.add_command(init)

cli.add_command(run)

cli.add_command(add)
cli.add_command(plugin)

def main():
    cli()

if __name__ == '__main__':
    main()
