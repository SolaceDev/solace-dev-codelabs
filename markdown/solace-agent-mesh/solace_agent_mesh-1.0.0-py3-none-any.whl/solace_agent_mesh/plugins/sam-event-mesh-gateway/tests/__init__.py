"""Integration tests for the SAM Event Mesh Gateway plugin."""
