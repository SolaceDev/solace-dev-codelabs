"""
Solace Agent Mesh - Event Mesh Gateway Plugin
Connects external systems to SAM agents via Solace PubSub+ events.
"""

__version__ = "0.1.0"
