# sam-bedrock-agent SAM Plugin

This plugin allows you to import one or multiple Amazon bedrock agents or flows as action to be used in your SAM project.

This is a plugin for the Solace Agent Mesh (SAM).


## Installation

The Amazon Bedrock Agent allows you to import one or multiple Amazon Bedrock agents or flows as actions to be used in your SAM project. This is useful for integrating with Amazon Bedrock's capabilities directly into your Solace Agent Mesh (SAM) project.

## Using the Plugin Store

Open the plugin store in your SAM project:
```bash
sam plugin store
```
Search for `sam-bedrock-agent` and install it. This will automatically add the plugin to your SAM project.

## CLI Installation

You can also install the plugin directly using the CLI. Run the following command in your SAM project directory:

```bash
solace-agent-mesh plugin add <your-new-component-name> --plugin sam-bedrock-agent
```

This will create a new component configuration at `configs/plugins/<your-new-component-name-kebab-case>.yaml`.

## Configuration

There is 2 sections in the configuration file that must be updated.

Section one, indicated by `# 1. UPDATE REQUIRED - START #`, contains the configuration for the Amazon Bedrock Agent/Flow and the internal configuration for the Agent.


Section two, indicated by `# 2. UPDATE REQUIRED - START #`, contains the configuration for the public facing API of the Agent which will be used by other agnets to interact with it.