"""
Solace Agent Mesh - SQL Database Agent Plugin
Provides natural language querying capabilities for SQL databases.
"""

__version__ = "0.1.0" # Initial version
