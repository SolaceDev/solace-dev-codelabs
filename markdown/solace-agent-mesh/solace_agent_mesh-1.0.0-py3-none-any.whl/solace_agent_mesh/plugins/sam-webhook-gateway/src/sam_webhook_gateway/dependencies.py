# src/gateway/webhook/dependencies.py
"""
Defines FastAPI dependency injectors to access shared resources
managed by the WebhookGatewayComponent.
"""

from fastapi import Depends, HTTPException, status
from typing import TYPE_CHECKING

# Import SAC logger
from solace_ai_connector.common.log import log

if TYPE_CHECKING:
    # Import the specific component type for accurate type hinting
    from .component import WebhookGatewayComponent

# Placeholder for Component Reference
# This will be set by the component during startup via set_component_instance
sac_component_instance: "WebhookGatewayComponent" = None


# Setup Function
def set_component_instance(component: "WebhookGatewayComponent"):
    """Called by the WebhookGatewayComponent during its startup to provide its instance."""
    global sac_component_instance
    if sac_component_instance is None:
        sac_component_instance = component
        log.info(
            "[Webhook Dependencies] SAC Component instance (WebhookGatewayComponent) provided."
        )
    else:
        log.warning(
            "[Webhook Dependencies] SAC Component instance (WebhookGatewayComponent) already set."
        )


# Core Dependency Getter
def get_sac_component() -> "WebhookGatewayComponent":
    """FastAPI dependency to get the WebhookGatewayComponent instance."""
    if sac_component_instance is None:
        # This should not happen if setup_dependencies is called correctly during startup
        log.critical(
            "[Webhook Dependencies] WebhookGatewayComponent instance accessed before it was set!"
        )
        raise HTTPException(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            detail="Webhook Gateway backend component not yet initialized.",
        )
    return sac_component_instance


# Add other specific dependency injectors here if needed by webhook route handlers.
# For now, get_sac_component() is the primary one, allowing access to all
# component methods and attributes.
