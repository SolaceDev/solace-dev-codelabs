# src/gateway/webhook/__init__.py
"""
Universal Webhook Gateway for the Solace AI Connector.

This gateway allows external systems to trigger A2A tasks via HTTP webhooks.
"""
