"""
Gateway implementation that provides a REST API for task submission and management.
"""
