"""
This package contains the FastAPI router modules for the REST API Gateway.
"""
