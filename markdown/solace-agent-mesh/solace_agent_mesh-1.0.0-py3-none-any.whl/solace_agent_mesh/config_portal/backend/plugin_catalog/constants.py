import os
from pathlib import Path 

try:
    from cli.utils import get_sam_cli_home_dir, get_cli_root_dir
    SAM_HOME = get_sam_cli_home_dir()
    DEFAULT_OFFICIAL_REGISTRY_URL = str(get_cli_root_dir() / "plugins")
except ImportError:
    # Fallback if 'cli.utils' is not importable in the current context (e.g., running backend standalone)
    # This fallback maintains the old behavior but logs a warning.
    # For full functionality with SAM_CLI_HOME, the backend should be run in a context where 'cli' is importable.
    print("WARNING: Could not import 'get_sam_cli_home_dir' from 'cli.utils'. "
          "Falling back to legacy ~/.sam paths for Plugin Catalog. "
          "SAM_CLI_HOME environment variable will not be respected in this mode.")
    SAM_HOME = Path(os.path.expanduser("~/.sam"))
    SAM_HOME.mkdir(parents=True, exist_ok=True) # Ensure fallback dir exists
    DEFAULT_OFFICIAL_REGISTRY_URL = "https://github.com/SolaceLabs/solace-agent-mesh-core-plugins"

# Example: if 'special-plugin' in the official repo should not be marked official
IGNORE_OFFICIAL_FLAG_REPOS = []

# Define paths relative to SAM_HOME
USER_REGISTRIES_PATH = SAM_HOME / "plugin_catalog_registries.json"
PLUGIN_CATALOG_TEMP_DIR = SAM_HOME / "plugin_catalog_tmp" # For cloning repos