# config_portal/backend/plugin_catalog/models.py
from typing import List, Optional, Dict, Any
from pydantic import BaseModel, HttpUrl

class PyProjectAuthor(BaseModel):
    name: Optional[str] = None
    email: Optional[str] = None

class PyProjectDetails(BaseModel):
    name: str
    version: str
    description: Optional[str] = None
    authors: Optional[List[PyProjectAuthor]] = None
    plugin_type: Optional[str] = "custom" # Type of plugin, e.g., "agent", "gateway", "custom"
    custom_metadata: Optional[Dict[str, Any]] = None # For all other metadata under [tool.<plugin_name>.metadata]
class AgentCardSkill(BaseModel):
    name: str
    description: Optional[str] = None
    # Add other fields from skill object as needed
    # e.g. input_schema: Optional[Dict[str, Any]] = None
    #      output_schema: Optional[Dict[str, Any]] = None
    
class AgentCard(BaseModel):
    displayName: Optional[str] = None
    shortDescription: Optional[str] = None # This might be different from pyproject.description
    # icon_url: Optional[HttpUrl] = None # If you plan to support icons
    Skill: Optional[List[AgentCardSkill]] = None # Note: 'Skill' as per user feedback
    # Add other fields from agent_card as needed

class PluginScrapedInfo(BaseModel):
    id: str # e.g., registry_name_or_hash + plugin_dir_name
    pyproject: PyProjectDetails
    readme_content: Optional[str] = None
    agent_card: Optional[AgentCard] = None
    source_registry_name: Optional[str] = None # Name of the registry this plugin came from
    source_registry_location: str # Path (if local) or URL (if git) of the registry
    source_type: str # 'git' or 'local'
    plugin_subpath: str # Relative path of the plugin within the registry
    is_official: bool
    # local_git_path: Optional[str] = None # Path if cloned locally for installation

class Registry(BaseModel):
    id: str # Unique ID for the registry (e.g., hash of path_or_url)
    path_or_url: str # Can be a local file path or a Git URL
    name: Optional[str] = None # User-provided or derived name
    type: str # 'git' or 'local'
    is_default: bool = False # Is it one of the initial default registries
    is_official_source: bool = False # Does this registry primarily host "official" plugins