# config_portal/backend/plugin_catalog_server.py
from flask import Flask, jsonify, request, send_from_directory
import os
import shutil
import logging
from pathlib import Path

# Assuming the Pylint issues are resolved by __init__.py files,
# these relative imports should now work.
from .plugin_catalog.scraper import PluginScraper
from .plugin_catalog.registry_manager import RegistryManager
from .plugin_catalog.constants import PLUGIN_CATALOG_TEMP_DIR

logger = logging.getLogger(__name__)
# Basic logging configuration - ideally, this should be configured globally for the app
# If not already configured by another part of the application:
if not logger.hasHandlers(): # Check if handlers are already configured
    logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')


# Global instances (or manage them via app context if preferred for larger apps)
registry_manager = RegistryManager()
plugin_scraper = PluginScraper()

def create_plugin_catalog_app(shared_config=None):
    # Determine the correct path to the 'frontend/dist' folder
    # Assuming this file (plugin_catalog_server.py) is in config_portal/backend/
    # Then static_folder should be ../../frontend/dist relative to this file's directory
    current_dir = Path(__file__).parent
    static_folder_path = Path(__file__).resolve().parent.parent / "frontend" / "static" / "client"   
    app = Flask(__name__, static_folder=str(static_folder_path), static_url_path='')
    app.config['SHARED_CONFIG'] = shared_config 

    # Initial scrape on startup
    # Consider doing this in a background thread for non-blocking startup in a real server.
    # For a local GUI tool, direct call might be acceptable if fast enough.
    logger.info("Performing initial plugin scrape on startup...")
    try:
        initial_registries = registry_manager.get_all_registries()
        plugin_scraper.get_all_plugins(initial_registries, force_refresh=True)
        logger.info(f"Initial scrape complete. Found {len(plugin_scraper.plugin_cache)} plugins.")
    except Exception as e:
        logger.error(f"Error during initial plugin scrape: {e}", exc_info=True)


    @app.route('/')
    def serve_index():
        # Ensure config_mode=pluginCatalog is handled by frontend router
        # The static_folder is already configured for Flask.
        # We just need to serve the main entry point of the React app.
        return send_from_directory(app.static_folder, 'index.html')

    # This route is often handled by Flask's static_folder serving if files are directly in 'assets'
    # under the static_folder. If Remix puts them in 'dist/assets', this explicit route is good.
    @app.route('/assets/<path:filename>')
    def serve_assets(filename):
        assets_dir = Path(app.static_folder) / 'assets'
        return send_from_directory(str(assets_dir), filename)

    @app.route('/api/plugin_catalog/plugins', methods=['GET'])
    def get_plugins_api():
        search_query = request.args.get('search', '').lower()
        
        # Ensure cache is populated if accessed directly and not yet populated
        if not plugin_scraper.is_cache_populated:
             logger.info("Plugin cache not populated, attempting to refresh for /api/plugin_catalog/plugins request.")
             all_regs = registry_manager.get_all_registries()
             plugin_scraper.get_all_plugins(all_regs, force_refresh=True)

        plugins_to_filter = plugin_scraper.plugin_cache
        
        if search_query:
            plugins_to_filter = [
                p for p in plugins_to_filter 
                if search_query in p.pyproject.name.lower() or \
                   (p.pyproject.description and search_query in p.pyproject.description.lower())
            ]
        return jsonify([p.model_dump(exclude_none=True) for p in plugins_to_filter])

    @app.route('/api/plugin_catalog/plugins/<plugin_id>/details', methods=['GET'])
    def get_plugin_details_api(plugin_id: str):
        details = plugin_scraper.get_plugin_details(plugin_id)
        if details:
            return jsonify(details.model_dump(exclude_none=True))
        return jsonify({"error": "Plugin not found", "status": "failure"}), 404

    @app.route('/api/plugin_catalog/plugins/install', methods=['POST'])
    def install_plugin_api():
        data = request.json
        if not data:
            return jsonify({"error": "Request body must be JSON", "status": "failure"}), 400
            
        plugin_id = data.get('pluginId')
        component_name = data.get('componentName')

        if not plugin_id or not component_name:
            return jsonify({"error": "pluginId and componentName are required", "status": "failure"}), 400

        plugin_info = plugin_scraper.get_plugin_details(plugin_id)
        if not plugin_info:
            return jsonify({"error": "Plugin not found to install", "status": "failure"}), 404
        
        success, message = plugin_scraper.install_plugin_cli(plugin_info, component_name)
        if success:
            return jsonify({"message": message, "status": "success"})
        else:
            # Return 500 for server-side/CLI errors, 400 if it was a bad request (e.g. invalid component name pattern - not checked here yet)
            return jsonify({"error": message, "status": "failure"}), 500


    @app.route('/api/plugin_catalog/registries', methods=['GET'])
    def get_registries_api():
        registries = registry_manager.get_all_registries()
        return jsonify([r.model_dump(exclude_none=True) for r in registries])

    @app.route('/api/plugin_catalog/registries', methods=['POST'])
    def add_registry_api():
        data = request.json
        if not data:
            return jsonify({"error": "Request body must be JSON", "status": "failure"}), 400
        
        path_or_url = data.get('path_or_url')
        name = data.get('name') # Optional

        if not path_or_url:
            return jsonify({"error": "path_or_url is required", "status": "failure"}), 400
        
        if registry_manager.add_registry(path_or_url, name=name):
            logger.info(f"Registry '{path_or_url}' (Name: {name if name else 'N/A'}) added by user. Refreshing plugins.")
            all_regs = registry_manager.get_all_registries()
            plugin_scraper.get_all_plugins(all_regs, force_refresh=True)
            return jsonify({"message": "Registry added and plugins refreshed.", "status": "success"})
        else:
            # This could be a duplicate, an invalid path/URL format, or a local path that doesn't exist.
            return jsonify({"error": "Failed to add registry (possibly duplicate, invalid path/URL, or local path issue)"}), 400


    @app.route('/api/plugin_catalog/registries/refresh', methods=['POST'])
    def refresh_registries_api():
        logger.info("Refreshing all plugin registries via API call...")
        all_regs = registry_manager.get_all_registries()
        plugin_scraper.get_all_plugins(all_regs, force_refresh=True)
        logger.info(f"Refresh complete. Found {len(plugin_scraper.plugin_cache)} plugins.")
        return jsonify({"message": f"Registries refreshed. Found {len(plugin_scraper.plugin_cache)} plugins.", "status": "success"})

    @app.route('/api/shutdown', methods=['POST'])
    def shutdown_api():
        # This is for the CLI-launched GUI to signal shutdown
        shared_config = app.config.get('SHARED_CONFIG')
        if shared_config is not None:
            shared_config['status'] = 'shutdown_requested'

        temp_dir_path = Path(os.path.expanduser(PLUGIN_CATALOG_TEMP_DIR))
        if temp_dir_path.exists():
            logger.info(f"Cleaning up temporary directory: {temp_dir_path}")
            try:
                shutil.rmtree(temp_dir_path)
            except Exception as e:
                logger.error(f"Error cleaning up temporary directory {temp_dir_path}: {e}")

        # Standard way to shutdown Werkzeug dev server
        func = request.environ.get('werkzeug.server.shutdown')
        if func is None:
            logger.warning("Werkzeug server shutdown function not found. Attempting os._exit(0).")
            # Fallback for other servers or if not running in Werkzeug's main thread
            # This is a forceful exit and might not be clean.
            os._exit(0) 
        try:
            func()
            logger.info("Server shutdown initiated.")
        except Exception as e:
            logger.error(f"Error during server shutdown: {e}. Forcing exit.")
            os._exit(1) # Exit with error if shutdown func fails
        return jsonify({"status": "success", "message": "Server shutting down"})
            
    return app

if __name__ == '__main__':
    # This is for direct testing of this Flask app, not for CLI launch
    # The CLI launch will use the run_flask_plugin_catalog from catalog_cmd.py
    app = create_plugin_catalog_app()
    print("Starting Plugin Catalog Flask app directly for testing on http://127.0.0.1:5003")
    app.run(host="127.0.0.1", port=5003, debug=True)