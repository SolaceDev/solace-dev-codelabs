# src/core_a2a/__init__.py
"""Core A2A Service Layer for decoupling gateway logic."""
