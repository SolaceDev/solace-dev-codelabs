# src/common/utils/embeds/resolver.py
"""
Contains the main embed resolution functions, including the chain executor.
"""

import asyncio
import re
import base64
import json
import csv
import io
from typing import Any, Callable, Dict, Optional, Set, Tuple, List

# Import SAC logger
from solace_ai_connector.common.log import log

from typing import Any, Callable, Dict, Optional, Set, Tuple, List, Union  # Added Union

# Import SAC logger
from solace_ai_connector.common.log import log

# Import from other modules within this package
from .constants import (
    EMBED_REGEX,
    EMBED_DELIMITER_OPEN,
    EMBED_DELIMITER_CLOSE,  # Added CLOSE for buffering check
    EMBED_CHAIN_DELIMITER,
    EARLY_EMBED_TYPES,
    LATE_EMBED_TYPES,
    # TEXT_CONTAINER_MIME_TYPES, # No longer needed here, is_text_based_mime_type handles it
)

# Import _evaluate_artifact_content_embed for use in _evaluate_artifact_content_embed_with_chain
from .evaluators import EMBED_EVALUATORS, _evaluate_artifact_content_embed
from .modifiers import MODIFIER_DEFINITIONS, _parse_modifier_chain
from .converter import (
    convert_data,
    serialize_data,
    _parse_string_to_list_of_dicts,
)
from .types import DataFormat
from ..mime_helpers import is_text_based_mime_type  # Import for step 2.3


# Optional dependency for YAML parsing
try:
    import yaml
    from .converter import PYYAML_AVAILABLE
except ImportError:
    PYYAML_AVAILABLE = False


# --- Helper for Logging Data ---
def _log_data_state(
    log_id: str,
    step: str,
    data: Any,
    data_format: Optional[DataFormat],
    mime_type: Optional[str],
):
    """Logs the state of the data at a specific step."""
    data_type = type(data).__name__
    data_size = "N/A"
    data_preview = "N/A"

    if isinstance(data, (bytes, str, list)):
        data_size = str(len(data))
    elif isinstance(data, dict):
        data_size = f"{len(data)} keys"

    if isinstance(data, bytes):
        try:
            # Try decoding first few bytes for preview
            data_preview = data[:100].decode("utf-8", errors="replace") + (
                "..." if len(data) > 100 else ""
            )
        except Exception:
            data_preview = f"Bytes[{len(data)}]"
    elif isinstance(data, str):
        data_preview = data[:100] + ("..." if len(data) > 100 else "")
    elif isinstance(data, list):
        data_preview = f"List[{len(data)} items]"
        if data and isinstance(data[0], dict):
            data_preview += f" (First item keys: {list(data[0].keys())[:5]}{'...' if len(data[0].keys()) > 5 else ''})"
    elif isinstance(data, dict):
        data_preview = f"Dict[{len(data)} keys: {list(data.keys())[:5]}{'...' if len(data.keys()) > 5 else ''}]"
    else:
        data_preview = str(data)[:100] + ("..." if len(str(data)) > 100 else "")

    log.info(
        "%s [%s] Format: %s, MimeType: %s, Type: %s, Size: %s, Preview: '%s'",
        log_id,
        step,
        data_format.name if data_format else "None",
        mime_type,
        data_type,
        data_size,
        data_preview,
    )


# --- Chain Executor Function ---


async def _evaluate_artifact_content_embed_with_chain(
    artifact_spec_from_directive: str,  # Renamed for clarity
    modifiers_from_directive: List[Tuple[str, str]],  # Renamed for clarity
    output_format_from_directive: Optional[str],  # Renamed for clarity
    context: Any,
    log_identifier: str,
    config: Optional[Dict] = None,
    current_depth: int = 0,  # New parameter for recursion depth
    visited_artifacts: Optional[
        Set[Tuple[str, int]]
    ] = None,  # New parameter for loop detection
    # parent_accumulated_size and max_total_size_for_parent are not directly used here,
    # but by the calling resolve_embeds_recursively_in_string
) -> Tuple[str, Optional[str], int]:  # Return (resolved_str, error_msg, size_of_embed)
    """
    Loads artifact content, recursively resolves its internal embeds if text-based,
    applies a chain of modifiers, and serializes the final result.
    """
    log.info(
        "%s [Depth:%d] Starting chain execution for artifact directive: %s",
        log_identifier,
        current_depth,
        artifact_spec_from_directive,
    )
    visited_artifacts = visited_artifacts or set()

    # 1. Parse the artifact_spec part of the directive (without modifiers)
    #    _parse_modifier_chain is not needed here as modifiers are already separated by evaluate_embed.
    #    The artifact_spec_from_directive IS the actual spec (filename:version).
    parsed_artifact_spec = artifact_spec_from_directive  # Use directly

    # 2. Load Initial Artifact Content
    # _evaluate_artifact_content_embed returns (content_bytes, mime_type, error_message)
    loaded_content_bytes, original_mime_type, load_error = (
        await _evaluate_artifact_content_embed(
            parsed_artifact_spec, context, log_identifier, config
        )
    )

    if load_error:
        log.warning(
            "%s [Depth:%d] Error loading initial artifact '%s': %s",
            log_identifier,
            current_depth,
            parsed_artifact_spec,
            load_error,
        )
        err_str = f"[Error loading artifact '{parsed_artifact_spec}': {load_error}]"
        return err_str, load_error, len(err_str.encode("utf-8"))

    if loaded_content_bytes is None:  # Should be caught by load_error, but defensive
        err_msg = f"Internal error - Artifact load for '{parsed_artifact_spec}' returned None content without error."
        log.error("%s %s", log_identifier, err_msg)
        return f"[Error: {err_msg}]", err_msg, 0

    current_data: Any = loaded_content_bytes
    current_format: DataFormat = DataFormat.BYTES
    _log_data_state(
        log_identifier,
        f"[Depth:{current_depth}] Initial Load",
        current_data,
        current_format,
        original_mime_type,
    )

    # 3. Recursive Resolution for Text-Based Content / Initial Data Setup for Modifiers
    if is_text_based_mime_type(original_mime_type):
        try:
            decoded_content = loaded_content_bytes.decode("utf-8")
            log.debug(
                "%s [Depth:%d] Artifact '%s' is text-based (%s). Attempting recursive embed resolution.",
                log_identifier,
                current_depth,
                parsed_artifact_spec,
                original_mime_type,
            )
            # Prepare for recursive call
            spec_parts = parsed_artifact_spec.split(":", 1)
            filename_for_key = spec_parts[0]
            version_str_for_key = spec_parts[1] if len(spec_parts) > 1 else None
            try:
                version_for_key = (
                    int(version_str_for_key) if version_str_for_key else -1
                )
            except ValueError:
                log.warning(
                    "%s Could not parse version from '%s' for visited_artifacts key. Loop detection might be affected.",
                    log_identifier,
                    parsed_artifact_spec,
                )
                version_for_key = -1

            artifact_key = (filename_for_key, version_for_key)
            new_visited_artifacts = visited_artifacts.copy()
            new_visited_artifacts.add(artifact_key)

            # Result of recursive resolution is always a string
            resolved_string_content = await resolve_embeds_recursively_in_string(
                text=decoded_content,
                context=context,
                resolver_func=evaluate_embed,
                types_to_resolve=EARLY_EMBED_TYPES.union(LATE_EMBED_TYPES),
                log_identifier=log_identifier,
                config=config,
                max_depth=config.get("gateway_recursive_embed_depth", 12),
                current_depth=current_depth + 1,
                visited_artifacts=new_visited_artifacts,
                accumulated_size=0,
                max_total_size=config.get(
                    "gateway_max_artifact_resolve_size_bytes", -1
                ),
            )
            # Update current_data and current_format for the modifier chain
            current_data = resolved_string_content
            current_format = DataFormat.STRING
            _log_data_state(
                log_identifier,
                f"[Depth:{current_depth}] After Recursive Resolution",
                current_data,
                current_format,
                original_mime_type,
            )

        except UnicodeDecodeError as ude:
            err_msg = f"Failed to decode text-based artifact '{parsed_artifact_spec}' for recursion: {ude}"
            log.warning("%s %s", log_identifier, err_msg)
            return f"[Error: {err_msg}]", err_msg, 0
        except Exception as recurse_err:
            err_msg = f"Error during recursive resolution of '{parsed_artifact_spec}': {recurse_err}"
            log.exception("%s %s", log_identifier, err_msg)
            return f"[Error: {err_msg}]", err_msg, 0
    else:
        # For non-text-based types, current_data (loaded_content_bytes) and
        # current_format (DataFormat.BYTES) were set after initial load and remain unchanged here.
        # No decode attempt. Modifiers will receive bytes.
        log.debug(
            "%s [Depth:%d] Artifact '%s' is not text-based (%s). Passing raw bytes to modifier chain.",
            log_identifier,
            current_depth,
            parsed_artifact_spec,
            original_mime_type,
        )
        # current_data and current_format are already correct (bytes, DataFormat.BYTES)
        # _log_data_state was already called after initial load.

    # --- Phase 1: Pre-parsing Logic ---
    if current_format == DataFormat.STRING and original_mime_type:
        normalized_mime_type = original_mime_type.lower()
        log.debug(
            "%s [Depth:%d] Pre-parsing string content with MIME type: %s",
            log_identifier,
            current_depth,
            normalized_mime_type,
        )
        if "json" in normalized_mime_type:
            try:
                current_data = json.loads(current_data)
                current_format = DataFormat.JSON_OBJECT
                log.info(
                    "%s [Depth:%d] Pre-parsed string as JSON_OBJECT.",
                    log_identifier,
                    current_depth,
                )
            except json.JSONDecodeError:
                log.warning(
                    "%s [Depth:%d] Failed to pre-parse as JSON despite MIME type '%s'. Content will be treated as STRING.",
                    log_identifier,
                    current_depth,
                    original_mime_type,
                )
        elif "yaml" in normalized_mime_type or "yml" in normalized_mime_type:
            if PYYAML_AVAILABLE:
                try:
                    current_data = yaml.safe_load(current_data)
                    current_format = DataFormat.JSON_OBJECT  # YAML loads to dict/list
                    log.info(
                        "%s [Depth:%d] Pre-parsed string as YAML (now JSON_OBJECT).",
                        log_identifier,
                        current_depth,
                    )
                except yaml.YAMLError:
                    log.warning(
                        "%s [Depth:%d] Failed to pre-parse as YAML despite MIME type '%s'. Content will be treated as STRING.",
                        log_identifier,
                        current_depth,
                        original_mime_type,
                    )
            else:
                log.warning(
                    "%s [Depth:%d] Skipping YAML pre-parsing for MIME type '%s' because PyYAML is not installed.",
                    log_identifier,
                    current_depth,
                    original_mime_type,
                )
        elif "csv" in normalized_mime_type:
            parsed_data, error_msg = _parse_string_to_list_of_dicts(
                current_data, original_mime_type, log_identifier
            )
            if error_msg is None and parsed_data is not None:
                current_data = parsed_data
                current_format = DataFormat.LIST_OF_DICTS
                log.info(
                    "%s [Depth:%d] Pre-parsed string as LIST_OF_DICTS from CSV.",
                    log_identifier,
                    current_depth,
                )
            else:
                log.warning(
                    "%s [Depth:%d] Failed to pre-parse as CSV despite MIME type '%s': %s. Content will be treated as STRING.",
                    log_identifier,
                    current_depth,
                    original_mime_type,
                    error_msg,
                )

        _log_data_state(
            log_identifier,
            f"[Depth:{current_depth}] After Pre-parsing",
            current_data,
            current_format,
            original_mime_type,
        )
    # --- End Pre-parsing ---

    # 4. Apply Modifiers Sequentially
    # current_data can be bytes or string, current_format reflects this.
    modifier_index = 0
    for prefix, value in modifiers_from_directive:  # Use renamed parameter
        modifier_index += 1
        modifier_step_id = f"Modifier {modifier_index} ({prefix})"

        modifier_def = MODIFIER_DEFINITIONS.get(prefix)
        if not modifier_def:
            err_msg = f"Unknown modifier prefix: '{prefix}'"
            log.warning("%s %s", log_identifier, err_msg)
            return f"[Error: {err_msg}]", err_msg, 0

        modifier_func = modifier_def["function"]
        accepts_formats: List[DataFormat] = modifier_def["accepts"]
        produces_format: DataFormat = modifier_def["produces"]

        log.info(
            "%s [Depth:%d][%s] Applying modifier: %s:%s (Accepts: %s, Produces: %s)",
            log_identifier,
            current_depth,
            modifier_step_id,
            prefix,
            value[:50] + "...",
            [f.name for f in accepts_formats],
            produces_format.name,
        )

        # 4a. Convert Data if Necessary (current_data is string, current_format is STRING)
        if current_format not in accepts_formats:
            target_format_for_modifier = accepts_formats[
                0
            ]  # Convert to the first accepted format
            log.info(
                "%s [Depth:%d][%s] Current format %s not accepted by %s. Converting to %s...",
                log_identifier,
                current_depth,
                modifier_step_id,
                current_format.name,
                prefix,
                target_format_for_modifier.name,
            )
            _log_data_state(
                log_identifier,
                f"[Depth:{current_depth}] {modifier_step_id} - Before Conversion",
                current_data,
                current_format,
                original_mime_type,
            )
            converted_data, new_format, convert_error = convert_data(
                current_data,
                current_format,  # Should be STRING
                target_format_for_modifier,
                log_identifier,
                original_mime_type,  # Pass original MIME of the base artifact
            )
            if convert_error:
                err_msg = (
                    f"Failed to convert data for modifier '{prefix}': {convert_error}"
                )
                log.warning("%s %s", log_identifier, err_msg)
                return f"[Error: {err_msg}]", err_msg, 0
            current_data = converted_data
            current_format = new_format
            log.info(
                "%s [Depth:%d][%s] Conversion successful. New format: %s",
                log_identifier,
                current_depth,
                modifier_step_id,
                current_format.name,
            )
            _log_data_state(
                log_identifier,
                f"[Depth:{current_depth}] {modifier_step_id} - After Conversion",
                current_data,
                current_format,
                original_mime_type,
            )

        # 4b. Execute Modifier
        try:
            _log_data_state(
                log_identifier,
                f"[Depth:{current_depth}] {modifier_step_id} - Before Execution",
                current_data,
                current_format,
                original_mime_type,
            )
            if prefix == "apply_to_template":
                result_data, _, exec_error = await modifier_func(
                    current_data, value, original_mime_type, log_identifier, context
                )
            else:
                if asyncio.iscoroutinefunction(modifier_func):
                    result_data, _, exec_error = await modifier_func(
                        current_data, value, original_mime_type, log_identifier
                    )
                else:
                    result_data, _, exec_error = modifier_func(
                        current_data, value, original_mime_type, log_identifier
                    )

            if exec_error:
                err_msg = f"Error applying modifier '{prefix}': {exec_error}"
                log.warning("%s %s", log_identifier, err_msg)
                return f"[Error: {err_msg}]", err_msg, 0

            current_data = result_data
            current_format = produces_format
            log.info(
                "%s [Depth:%d][%s] Modifier '%s' executed. Result format: %s",
                log_identifier,
                current_depth,
                modifier_step_id,
                prefix,
                current_format.name,
            )
            _log_data_state(
                log_identifier,
                f"[Depth:{current_depth}] {modifier_step_id} - After Execution",
                current_data,
                current_format,
                original_mime_type,
            )
            if current_data is None or (
                isinstance(current_data, (list, str, bytes)) and not current_data
            ):
                log.info(
                    "%s [Depth:%d][%s] Modifier '%s' resulted in empty data.",
                    log_identifier,
                    current_depth,
                    modifier_step_id,
                    prefix,
                )

        except Exception as mod_err:
            log.exception(
                "%s [Depth:%d][%s] Unexpected error executing modifier '%s': %s",
                log_identifier,
                current_depth,
                modifier_step_id,
                prefix,
                mod_err,
            )
            err_msg = f"Unexpected error in modifier '{prefix}': {mod_err}"
            return f"[Error: {err_msg}]", err_msg, 0

    # 5. Final Serialization
    target_string_format = output_format_from_directive  # Use renamed parameter
    if target_string_format is None:
        log.warning(
            "%s [Depth:%d] Missing final 'format:' step in chain. Defaulting to 'text'.",
            log_identifier,
            current_depth,
        )
        target_string_format = "text"

    log.info(
        "%s [Depth:%d] [Final Serialization] Serializing final data (Format: %s) to target string format '%s'",
        log_identifier,
        current_depth,
        current_format.name,
        target_string_format,
    )
    _log_data_state(
        log_identifier,
        f"[Depth:{current_depth}] Before Serialization",
        current_data,
        current_format,
        original_mime_type,
    )

    final_serialized_string, serialize_error = serialize_data(
        data=current_data,  # This is the (potentially wrongly decoded) string for non-image datauri or other formats
        data_format=current_format,
        target_string_format=target_string_format,  # This was set based on output_format_from_directive
        original_mime_type=original_mime_type,
        log_id=log_identifier,
    )

    if serialize_error:
        log.warning("%s [Depth:%d] %s", log_identifier, current_depth, serialize_error)
        return (
            final_serialized_string,
            serialize_error,
            len(final_serialized_string.encode("utf-8")),
        )

    final_size = len(final_serialized_string.encode("utf-8"))
    log.info(
        "%s [Depth:%d] Chain execution completed successfully. Final size: %d bytes.",
        log_identifier,
        current_depth,
        final_size,
    )
    log.info(
        "%s [Depth:%d] [Final Serialization] Result: '%s...'",
        log_identifier,
        current_depth,
        final_serialized_string[:100]
        + ("..." if len(final_serialized_string) > 100 else ""),
    )
    return final_serialized_string, None, final_size


# --- Main Resolution Functions ---


async def resolve_embeds_in_string(
    text: str,
    context: Any,
    resolver_func: Callable[
        ..., Union[Tuple[str, Optional[str], int], Tuple[None, str, Any]]
    ],
    types_to_resolve: Set[str],
    log_identifier: str = "[EmbedUtil]",
    config: Optional[Dict[str, Any]] = None,
) -> Tuple[str, int, List[Tuple[int, Any]]]:
    """
    Resolves specified embed types within a string using a provided resolver function.
    This is the TOP-LEVEL resolver called by gateways. It handles signals and buffering.
    It does NOT perform recursion itself but calls `evaluate_embed` which might trigger recursion.

    Processes the string iteratively, resolving one embed at a time.
    Includes buffering logic: stops processing if a partial embed delimiter is found
    at the end, returning the processed part and the index where processing stopped.
    Can now return special signals from the resolver function.

    Args:
        text: The input string potentially containing embeds.
        context: The context object passed to the resolver function (now a Dict).
        resolver_func: The function to call for evaluating each embed.
                       Signature: (type, expression, format, context, log_id, config, ...) -> Any
                       Can return a string for replacement, or a tuple like (None, "SIGNAL_TYPE", data)
                       to indicate a signal instead of text replacement.
        types_to_resolve: A set of embed types (strings) to resolve in this pass.
        log_identifier: Identifier for logging.
        config: Optional configuration dictionary passed to the resolver.

    Returns:
        A tuple containing:
        - The string with specified embeds resolved (or removed if signaled).
        - The index in the *original* string representing the end of the
          successfully processed portion (useful for buffering). This will be
          len(text) if the whole string was processed.
        - A list of signals encountered during resolution, as tuples (index, signal_data).
          The index corresponds to the start index of the embed directive in the original string.
    """
    resolved_parts = []
    signals_found: List[Tuple[int, Any]] = []
    last_end = 0
    original_length = len(text)

    log.debug(
        "%s Checking for embeds in text: '%s'", log_identifier, text[:200] + "..."
    )

    for match in EMBED_REGEX.finditer(text):
        start, end = match.span()
        embed_type = match.group(1)
        expression = match.group(2)
        format_spec = match.group(3)

        # Append text before the current match
        resolved_parts.append(text[last_end:start])

        if embed_type in types_to_resolve:
            log.info(
                "%s Found embed type '%s' to resolve: expr='%s', fmt='%s'",
                log_identifier,
                embed_type,
                expression,
                format_spec,
            )
            resolved_value = await resolver_func(
                embed_type,
                expression,
                format_spec,
                context,
                log_identifier,
                config,  # Pass config
            )

            # Check if the resolved value is a signal tuple (None, "SIGNAL_TYPE", data)
            if (
                isinstance(resolved_value, tuple)
                and len(resolved_value) == 3
                and resolved_value[0] is None
                and isinstance(resolved_value[1], str)  # Check for signal type string
            ):
                signal_type = resolved_value[1]
                # signal_data = resolved_value[2] # Data is part of resolved_value
                log.info(
                    "%s Received signal '%s' from resolver for embed at index %d.",
                    log_identifier,
                    signal_type,
                    start,
                )
                signals_found.append(
                    (
                        start,
                        resolved_value,
                    )  # Store the (None, "SIGNAL_TYPE", data) tuple
                )
                # Do NOT append anything to resolved_parts for signals
            # Check if it's a regular text result (text_content, error_message_if_any, size_of_text_content)
            elif (
                isinstance(resolved_value, tuple)
                and len(resolved_value) == 3
                and isinstance(
                    resolved_value[0], str
                )  # First element is string content or error
                # resolved_value[1] can be str (error) or None
                and isinstance(resolved_value[2], int)  # Third element is size
            ):
                text_content, error_message, _ = (
                    resolved_value  # Size not used by this top-level func
                )
                if error_message:
                    log.warning(
                        "%s Embed resolution for '%s:%s' resulted in error: %s. Using error string as content.",
                        log_identifier,
                        embed_type,
                        expression,
                        error_message,
                    )
                resolved_parts.append(
                    text_content
                )  # Append resolved text (or error string)
            else:
                # Fallback for unexpected return types from evaluate_embed
                log.warning(
                    "%s Resolver for type '%s' returned unexpected structure %s. Treating as error string.",
                    log_identifier,
                    embed_type,
                    type(resolved_value),
                )
                # Optionally append an error marker or empty string
                # resolved_parts.append(f"[Resolver Error: Unexpected type {type(resolved_value)}]")

        else:
            # Keep the embed directive as is if type is not in the set
            log.debug(
                "%s Skipping embed type '%s' (not in types_to_resolve)",
                log_identifier,
                embed_type,
            )
            resolved_parts.append(match.group(0))

        last_end = end

    # Append any remaining text after the last match
    remaining_text = text[last_end:]
    resolved_parts.append(remaining_text)

    potential_partial_embed = False
    partial_embed_start_index = -1

    # Find the last opening delimiter in the remaining text
    last_open_delimiter_index = remaining_text.rfind(EMBED_DELIMITER_OPEN)

    if last_open_delimiter_index != -1:
        # Check if a closing delimiter exists *after* the last opening delimiter
        # within the remaining_text
        closing_delimiter_index = remaining_text.find(
            EMBED_DELIMITER_CLOSE, last_open_delimiter_index
        )
        if closing_delimiter_index == -1:
            # No closing delimiter found after the last opening one in remaining_text
            potential_partial_embed = True
            # Calculate the index relative to the start of remaining_text
            partial_embed_start_index = last_open_delimiter_index
            log.debug(
                "%s Potential unclosed embed detected starting at index %d within remaining text: '%s...'",
                log_identifier,
                partial_embed_start_index,
                remaining_text[
                    partial_embed_start_index : partial_embed_start_index + 10
                ],
            )

    if potential_partial_embed:
        # Calculate the index in the *original* string where the partial embed starts
        processed_until_index = last_end + partial_embed_start_index
        # The text to return is everything *before* the start of the partial embed
        # This requires joining parts *before* the last one (remaining_text)
        final_text = (
            "".join(resolved_parts[:-1]) + remaining_text[:partial_embed_start_index]
        )
        log.debug(
            "%s Returning processed text up to index %d due to potential partial embed.",
            log_identifier,
            processed_until_index,
        )
    else:
        # No partial embed detected, process the whole string
        final_text = "".join(resolved_parts)
        processed_until_index = original_length
        log.debug(
            "%s Returning fully processed text (length %d).",
            log_identifier,
            len(final_text),
        )

    return final_text, processed_until_index, signals_found  # Return signals


async def resolve_embeds_recursively_in_string(
    text: str,
    context: Any,
    resolver_func: Callable[..., Tuple[str, Optional[str], int]],
    types_to_resolve: Set[str],
    log_identifier: str,
    config: Optional[Dict],  # context is part of config or passed separately
    max_depth: int,
    current_depth: int = 0,
    visited_artifacts: Optional[Set[Tuple[str, int]]] = None,
    accumulated_size: int = 0,
    max_total_size: int = -1,
) -> str:
    """
    Recursively resolves specified embed types within a string, respecting depth,
    loop detection (via visited_artifacts passed down), and accumulated size limits.
    """
    if current_depth >= max_depth:
        log.warning(
            "%s Max embed recursion depth (%d) reached for current processing string.",
            log_identifier,
            max_depth,
        )
        return "[Error: Max embed depth exceeded]"

    visited_artifacts = visited_artifacts or set()  # Ensure it's a set
    resolved_parts = []
    last_end = 0

    for match in EMBED_REGEX.finditer(text):
        start, end = match.span()
        embed_type = match.group(1)
        expression = match.group(2)
        format_spec = match.group(3)

        resolved_parts.append(text[last_end:start])

        if embed_type not in types_to_resolve:
            resolved_parts.append(match.group(0))
            last_end = end
            continue

        log.debug(
            "%s [Depth:%d] Found embed '%s' to resolve: expr='%s', fmt='%s'",
            log_identifier,
            current_depth,
            embed_type,
            expression,
            format_spec,
        )

        # Call the resolver_func. For artifact_content, this will eventually call
        # _evaluate_artifact_content_embed_with_chain, which handles its own recursion
        # and returns (resolved_string, error_message, size_of_this_embed).
        # For other embed types, evaluate_embed will return (resolved_string, None, len(resolved_string.encode()))
        # or (error_string, error_string, 0)
        # The resolver_func (evaluate_embed) needs to be passed current_depth and visited_artifacts
        # so it can correctly manage recursion for artifact_content embeds.
        # The config dict should contain max_depth and gateway_max_artifact_resolve_size_bytes.
        # The 'context' passed to resolver_func is now the dictionary.
        resolved_value = await resolver_func(  # resolver_func is evaluate_embed
            embed_type,
            expression,
            format_spec,
            context,  # Pass the dictionary context
            log_identifier,
            config,  # Pass config separately if evaluate_embed needs it directly, or ensure it's in context
            current_depth,
            visited_artifacts,
        )

        # Handle return from evaluate_embed (which could be text result or signal)
        # This recursive resolver should only deal with text results or errors for text.
        # Signals are handled by the top-level resolve_embeds_in_string.
        # If a signal were to be returned here, it would break the string construction.
        # For now, assume evaluate_embed called from here for recursive text resolution
        # will not itself return a signal, or if it does, it's an error for this path.

        if (
            isinstance(resolved_value, tuple)
            and len(resolved_value) == 3
            and isinstance(resolved_value[0], str)
            and isinstance(resolved_value[2], int)
        ):
            resolved_string_for_embed, error_msg_from_chain, size_of_this_embed = (
                resolved_value
            )
        else:
            # This case should ideally not be hit if evaluate_embed is used correctly for recursion.
            # If evaluate_embed returns a signal here, it's an issue.
            log.error(
                "%s [Depth:%d] Recursive call to resolver for '%s:%s' returned unexpected signal or format. Treating as error.",
                log_identifier,
                current_depth,
                embed_type,
                expression,
            )
            error_msg_from_chain = "Recursive resolution returned unexpected signal."
            resolved_string_for_embed = f"[Error: {error_msg_from_chain}]"
            size_of_this_embed = len(resolved_string_for_embed.encode("utf-8"))

        if error_msg_from_chain:
            log.warning(
                "%s [Depth:%d] Embed '%s:%s' resulted in error from chain: %s",
                log_identifier,
                current_depth,
                embed_type,
                expression,
                error_msg_from_chain,
            )
            resolved_parts.append(
                resolved_string_for_embed
            )  # This is the error message string
        else:
            # Perform total size check for the current string being processed
            if (
                max_total_size >= 0
                and accumulated_size + size_of_this_embed > max_total_size
            ):
                error_str = f"[Error: Embedding '{expression}' exceeds total size limit for parent content ({accumulated_size + size_of_this_embed} > {max_total_size})]"
                log.warning("%s %s", log_identifier, error_str)
                resolved_parts.append(error_str)
            else:
                resolved_parts.append(resolved_string_for_embed)
                accumulated_size += size_of_this_embed
                log.debug(
                    "%s [Depth:%d] Appended resolved embed (size: %d). Current accumulated_size: %d",
                    log_identifier,
                    current_depth,
                    size_of_this_embed,
                    accumulated_size,
                )

        last_end = end

    resolved_parts.append(text[last_end:])
    return "".join(resolved_parts)


# --- Main Evaluation Function ---


async def evaluate_embed(
    embed_type: str,
    expression: str,
    format_spec: Optional[str],
    context: Dict[str, Any],  # Changed context type to Dict
    log_identifier: str,
    config: Optional[Dict] = None,
    current_depth: int = 0,
    visited_artifacts: Optional[Set[Tuple[str, int]]] = None,
) -> Union[Tuple[str, Optional[str], int], Tuple[None, str, Any]]:
    """
    Evaluates a single embed directive.
    For 'artifact_content', it handles the modifier chain and potential internal recursion.
    For other types, it evaluates directly and returns a 3-tuple (text, error, size).
    For 'status_update', it returns a signal tuple (None, "SIGNAL_STATUS_UPDATE", data).

    Args:
        embed_type: The type of the embed.
        expression: The expression part of the embed.
        format_spec: The optional format specifier.
        context: The dictionary-based context (containing artifact_service, session_context, config).
        log_identifier: Identifier for logging.
        config: Optional configuration dictionary (now part of context or passed if needed by evaluators).
        current_depth: Current recursion depth (for artifact_content).
        visited_artifacts: Set of visited artifacts (for artifact_content).

    Returns:
        A 3-tuple (text_content, error_message, size) or a signal tuple (None, signal_type, data).
    """
    log.debug(
        "%s Evaluating embed: type='%s', expr='%s', fmt='%s'",
        log_identifier,
        embed_type,
        expression[:50] + "...",
        format_spec,
    )

    if embed_type == "status_update":
        status_text = expression.strip()
        log.info("%s Detected 'status_update' embed. Signaling.", log_identifier)
        # Return the special signal tuple
        return (None, "SIGNAL_STATUS_UPDATE", status_text)

    elif embed_type == "artifact_content":
        artifact_spec, modifiers, output_format = _parse_modifier_chain(expression)
        if (
            output_format is None and format_spec is not None
        ):  # format_spec is from «type:expr|format»
            log.warning(
                "%s Using format specifier '| %s' for artifact_content as chain format step was missing.",
                log_identifier,
                format_spec,
            )
            output_format = format_spec

        # Call _evaluate_artifact_content_embed_with_chain with recursion parameters
        # visited_artifacts is passed down from the caller (resolve_embeds_recursively_in_string)
        # or initialized here if this is a top-level call from resolve_embeds_in_string.
        final_string, error, size = await _evaluate_artifact_content_embed_with_chain(
            artifact_spec_from_directive=artifact_spec,  # Pass only the spec part
            modifiers_from_directive=modifiers,
            output_format_from_directive=output_format,
            context=context,
            log_identifier=log_identifier,
            config=config,
            current_depth=current_depth,  # Pass current_depth
            visited_artifacts=visited_artifacts or set(),  # Ensure it's a set
        )
        return final_string, error, size

    else:
        # Handle other (early stage) embed types
        evaluator = EMBED_EVALUATORS.get(embed_type)
        if not evaluator:
            err_msg = f"Unknown embed type: '{embed_type}'"
            log.warning("%s %s", log_identifier, err_msg)
            err_str = f"[Error: {err_msg}]"
            return err_str, err_msg, len(err_str.encode("utf-8"))

        try:
            # Evaluators for non-artifact_content types now return (str_value, error, size)
            if asyncio.iscoroutinefunction(evaluator):
                # Pass format_spec to all evaluators from the map
                str_value, eval_error, size = await evaluator(
                    expression, context, log_identifier, format_spec
                )
            else:
                str_value, eval_error, size = evaluator(
                    expression, context, log_identifier, format_spec
                )

            # No need for further serialization here as simple evaluators now return string and size.
            # The format_spec for simple types is handled within their evaluators (e.g., datetime for expression, math for format_spec)
            # or by Python's format() for numbers (handled in serialize_data, which simple evaluators might use internally if they produce numbers).
            # For now, assume simple evaluators directly produce the final string or an error string.
            return str_value, eval_error, size

        except Exception as e:
            log.exception(
                "%s Unexpected error evaluating %s embed '%s': %s",
                log_identifier,
                embed_type,
                expression,
                e,
            )
            err_msg = f"Unexpected evaluation error: {e}"
            err_str = f"[Error: {err_msg}]"
            return err_str, err_msg, len(err_str.encode("utf-8"))
