# src/common/utils/embeds/types.py
"""
Defines types used within the embed processing system, like DataFormat.
"""

from enum import Enum, auto

class DataFormat(Enum):
    """Represents internal data formats during modifier chain execution."""
    BYTES = auto()
    STRING = auto()
    JSON_OBJECT = auto() # Represents dict or list parsed from JSON
    LIST_OF_DICTS = auto() # Represents list[dict], typically from CSV
    # Add more formats as needed (e.g., CSV_READER, XML_DOM)
