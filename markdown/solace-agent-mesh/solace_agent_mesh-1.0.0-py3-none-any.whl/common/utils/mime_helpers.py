"""
Utility functions for handling MIME types.
"""

from typing import Optional, Set

# Define TEXT_CONTAINER_MIME_TYPES locally to break import cycle
TEXT_CONTAINER_MIME_TYPES: Set[str] = {
    "text/plain",
    "text/markdown",
    "text/html",
    "application/json",
    "application/yaml",
    "text/yaml",
    "application/x-yaml",
    "text/x-yaml",
    "application/xml",
    "text/xml",
    "text/csv",
    # Add other text-based types that might contain embeds
}


def is_text_based_mime_type(mime_type: Optional[str]) -> bool:
    """
    Checks if a given MIME type is considered text-based.

    Args:
        mime_type: The MIME type string (e.g., "text/plain", "application/json").

    Returns:
        True if the MIME type is text-based, False otherwise.
    """
    if not mime_type:
        return False

    normalized_mime_type = mime_type.lower().strip()

    if normalized_mime_type.startswith("text/"):
        return True

    if normalized_mime_type in TEXT_CONTAINER_MIME_TYPES:
        return True

    return False
