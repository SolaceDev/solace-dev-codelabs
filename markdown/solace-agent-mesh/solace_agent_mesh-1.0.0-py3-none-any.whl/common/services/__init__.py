"""
This package contains shared, reusable services for the Solace AI Connector,
such as the IdentityService.
"""
