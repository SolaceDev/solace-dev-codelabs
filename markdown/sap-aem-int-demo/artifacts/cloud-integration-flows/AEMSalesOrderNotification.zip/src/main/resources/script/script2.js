/* Refer the link below to learn more about the use cases of script.
https://help.sap.com/viewer/368c481cd6954bdfa5d0435479fd4eaf/Cloud/en-US/148851bf8192412cba1f9d2c17f4bd25.html

If you want to know more about the SCRIPT APIs, refer the link below
https://help.sap.com/doc/a56f52e1a58e4e2bac7f7adbf45b2e26/Cloud/en-US/index.html */
importClass(com.sap.gateway.ip.core.customdev.util.Message);
importClass(java.util.HashMap);

function processData(message) {
    //Body
    var DQMresponse = String(message.getBody( new java.lang.String().getClass()));
    DQMresponse = JSON.parse(DQMresponse);
    
    var origBody = message.getProperty("ORIGPAYLOAD");
    var origTopic = message.getProperty("ORIGTOPIC");
    origBody = JSON.parse(origBody);
    
    var i=0;
    origBody.orderHeader.forEach(function(order){
        order.customer.forEach(function(cust){
            const currAddress=DQMresponse.addressOutput[i];
            //copy content from each addressoutput into customer addressoutput
            cust.street = currAddress.std_addr_prim_address + currAddress.std_addr_sec_address;
            cust.city = currAddress.std_addr_locality_full;
            cust.zipCode = currAddress.std_addr_postcode_full;
            cust.country = currAddress.std_addr_country_2char;
            //additional fields available, not used:
            //currAddress.std_addr_region_full
            //currAddress.addr_asmt_info
            i++;
        })
    })

    var topicLevels = origTopic.split("/");
    topicLevels[2] = "addressChecked";
    var outputTopic = topicLevels.join("/");
    message.setHeader("Destination", outputTopic);
    message.setBody(JSON.stringify(origBody));
    return message;
}